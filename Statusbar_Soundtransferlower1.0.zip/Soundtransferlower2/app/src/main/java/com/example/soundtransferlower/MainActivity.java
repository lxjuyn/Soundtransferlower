package com.example.soundtransferlower;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements AudioRecorderPlayer.AudioDataSender {
    private static final long TALK_BUTTON_TIMEOUT = 600; // 按钮禁用时间（毫秒）
    private boolean isTalkButtonDisabled = false; // 按钮禁用状态标志
    private static final String TAG = "MainActivity";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String APP_NAME = "SoundTransfer";
    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 1;
    private static final int AUDIO_BUFFER_SIZE = 640;
    private static final long RECEIVE_TIMEOUT = 800; // 接收超时时间（毫秒）
    private boolean isLoading = true;
    private static final long INACTIVITY_THRESHOLD_DISCONNECT = 50000; // 50秒断开阈值
    private long lastActivityTime = 0; // 最后活动时间戳
    private Runnable inactivityCheckRunnable; // 活动检测Runnable

    // 状态常量
    private int stateChangeCount = 0; // 状态切换计数器
    private static final int MAX_STATE_CHANGES = 6; // 最大状态切换次数
    private BluetoothDevice lastConnectedDevice = null; // 记录最后连接的设备
    private static final int STATE_IDLE = 0;
    private static final int STATE_TALKING = 1;
    private static final int STATE_RECEIVING = 2;

    private TextView tvStatus;
    private ListView deviceList;
    private Button btnRefresh, btnAudioMode, btnTalk, btnDisconnect, btnPair;
    private ArrayAdapter<BluetoothDevice> deviceAdapter;
    private List<BluetoothDevice> pairedDevices = new ArrayList<>();

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice targetDevice;
    private AcceptThread acceptThread;
    private ConnectThread connectThread;
    public ConnectedThread connectedThread;

    private AudioManager audioManager;
    private AudioRecorderPlayer audioRecorderPlayer;

    private boolean isRecording = false;
    private boolean isSpeakerMode = false; // 初始为听筒模式
    private boolean isConnectionActive = false;
    private boolean isConnecting = false;
    private boolean isIncomingConnection = false;
    private int currentState = STATE_IDLE;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshPairedDevices();
            handler.postDelayed(this, 5000);
        }
    };

    // 接收超时检测
    private Runnable receiveTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (currentState == STATE_RECEIVING) {
                Log.d(TAG, "接收超时，恢复空闲状态");
                setState(STATE_IDLE);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(intent);
        setLoadingState(); // 设置初始加载状态
        checkPermissions();
        initBluetooth();
        initAudio();
        setupListeners();
        handler.postDelayed(() -> {
            isLoading = false;
            setInitialState();
        }, 500);

        // 初始化活动检测计时器
        inactivityCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkInactivity();
                // 每1秒检查一次
                handler.postDelayed(this, 1000);
            }
        };
    }

    // 实现音频数据发送接口
    @Override
    public void sendAudioData(byte[] data) {
        if (connectedThread != null && isConnectionActive) {
            connectedThread.write(data);
            resetInactivityTimer();
        }
    }

    private void initViews() {
        tvStatus = findViewById(R.id.tvStatus);
        deviceList = findViewById(R.id.deviceList);
        btnRefresh = findViewById(R.id.btnRefresh);
        btnAudioMode = findViewById(R.id.btnAudioMode);
        btnTalk = findViewById(R.id.btnTalk);
        btnDisconnect = findViewById(R.id.btnDisconnect);
        btnPair = findViewById(R.id.btnPair);

        deviceAdapter = new DeviceListAdapter(this, R.layout.device_list_item, pairedDevices);
        deviceList.setAdapter(deviceAdapter);

        // 初始按钮文本
        btnAudioMode.setText("开始外放");
    }

    private void checkPermissions() {
        String[] permissions = {
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.MODIFY_AUDIO_SETTINGS
        };

        List<String> permissionsNeeded = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    permissionsNeeded.toArray(new String[0]),
                    REQUEST_BLUETOOTH_PERMISSIONS);
        }
    }

    @SuppressLint("MissingPermission")
    private void initBluetooth() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            tvStatus.setText("蓝牙不可用");
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBtIntent);
        }

        // 注册蓝牙状态广播接收器
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED);
        registerReceiver(bluetoothReceiver, filter);
    }

    private void initAudio() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioRecorderPlayer = new AudioRecorderPlayer(this);
        audioRecorderPlayer.setAudioDataSender(this);
        setSpeakerMode(false); // 初始为听筒模式
    }

    private void setupListeners() {
        deviceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                targetDevice = pairedDevices.get(position);
                connectToDevice(targetDevice);
            }
        });

        btnRefresh.setOnClickListener(v -> refreshPairedDevices());

        btnAudioMode.setOnClickListener(v -> {
            isSpeakerMode = !isSpeakerMode;
            setSpeakerMode(isSpeakerMode);
            // 更新按钮文本
            if (isSpeakerMode) {
                btnAudioMode.setText("关闭外放");
            } else {
                btnAudioMode.setText("开启外放");
            }
        });
        btnDisconnect.setOnClickListener(v -> disconnect());
        btnPair.setOnClickListener(v -> {
            Intent intent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
            startActivity(intent);
        });
        btnRefresh.setOnClickListener(v -> refreshPairedDevices());

        // 修改为点击监听器
        btnTalk.setOnClickListener(v -> {
            // 检查按钮是否被禁用
            if (isTalkButtonDisabled) {
                Toast.makeText(MainActivity.this, "请稍后再试", Toast.LENGTH_SHORT).show();
                return;
            }

            // 禁用按钮并设置超时
            disableTalkButtonTemporarily();

            // 原有功能逻辑
            if (isRecording) {
                stopTalking();
            } else {
                startTalking();
            }
        });
    }

    private void refreshPairedDevices() {
        if (bluetoothAdapter == null) return;

        @SuppressLint("MissingPermission") Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
        pairedDevices.clear();
        pairedDevices.addAll(devices);
        deviceAdapter.notifyDataSetChanged();
        Log.d(TAG, "刷新配对设备列表，数量: " + pairedDevices.size());
    }

    private void connectToDevice(BluetoothDevice device) {
        if (isConnectionActive || isConnecting) return;

        tvStatus.setText("连接中");
        isConnecting = true;
        btnTalk.setEnabled(false);
        btnDisconnect.setEnabled(false);

        // 停止接受线程
        if (acceptThread != null) {
            acceptThread.cancel();
            acceptThread = null;
        }

        // 启动连接线程
        connectThread = new ConnectThread(device);
        connectThread.start();
    }

    private void startServer() {
        if (acceptThread == null) {
            acceptThread = new AcceptThread();
            acceptThread.start();
            Log.d(TAG, "启动服务器线程");
        }
    }

    @SuppressLint({"MissingPermission", "SetTextI18n"})
    private void connected(BluetoothSocket socket) {
        Log.d(TAG, "连接成功");
        Log.d(TAG, "调用 connected() 方法");

        // 停止连接线程 - 但不立即取消
        if (connectThread != null) {
            // 不调用 connectThread.cancel()，只置为 null
            connectThread = null;
        }

        // 停止接受线程
        if (acceptThread != null) {
            acceptThread.cancel();
            acceptThread = null;
        }

        // 启动连接线程 - 传入 this 作为 Context
        connectedThread = new ConnectedThread(socket, this);
        connectedThread.start();

        // 更新UI
        runOnUiThread(() -> {
            tvStatus.setText("已连接: " + socket.getRemoteDevice().getName());
            btnTalk.setEnabled(true);
            btnTalk.setText("按下对讲");
            btnTalk.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_green_light));
            btnDisconnect.setEnabled(true);
            btnAudioMode.setEnabled(true);
            isConnectionActive = true;
            isConnecting = false;
            playConnectionSound();
            setState(STATE_IDLE);
            startInactivityTimer();
        });

        lastConnectedDevice = socket.getRemoteDevice();
    }

    private void handleConnectionLost() {
        Log.d(TAG, "连接丢失");
        runOnUiThread(() -> {
            resetConnectionState(); // 调用新的状态重置方法
            tvStatus.setText("连接断开");
        });
    }

    private void disableTalkButtonTemporarily() {
        isTalkButtonDisabled = true;
        btnTalk.setEnabled(false);
        btnTalk.setAlpha(0.5f); // 添加半透明效果表示禁用

        handler.postDelayed(() -> {
            isTalkButtonDisabled = false;
            // 只有在连接活跃时才重新启用按钮
            if (isConnectionActive) {
                btnTalk.setEnabled(true);
                btnTalk.setAlpha(1.0f); // 恢复不透明
                // 刷新按钮状态以确保UI一致
                setState(currentState);
            }
        }, TALK_BUTTON_TIMEOUT);
    }

    private void disconnect() {
        Log.d(TAG, "调用 disconnect() 方法");
        stopInactivityTimer();
        // 清理所有连接线程
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        if (acceptThread != null) {
            acceptThread.cancel();
            acceptThread = null;
        }

        runOnUiThread(() -> {
            resetConnectionState(); // 调用新的状态重置方法
            tvStatus.setText("已断开连接");
        });
    }

    private void resetConnectionState() {
        // 停止录音（如果正在录音）
        if (isRecording) {
            stopTalking();
        }

        // 重置连接相关状态
        isConnectionActive = false;
        isConnecting = false;
        isIncomingConnection = false;
        currentState = STATE_IDLE;
        stateChangeCount = 0; // 重置状态切换计数器

        // 重置UI状态
        btnTalk.setEnabled(false);
        btnTalk.setText("按下对讲");
        btnTalk.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        btnDisconnect.setEnabled(false);
        btnAudioMode.setEnabled(false);

        // 重新启用设备列表和刷新按钮
        deviceList.setEnabled(true);
        btnRefresh.setEnabled(true);
        btnPair.setEnabled(true);

        // 重启服务器监听
        startServer();
        isTalkButtonDisabled = false;
        btnTalk.setAlpha(1.0f);
    }

    // 添加计时器管理方法
    private void startInactivityTimer() {
        // 重置最后活动时间
        lastActivityTime = System.currentTimeMillis();
        // 启动计时器
        handler.postDelayed(inactivityCheckRunnable, 1000);
        Log.d(TAG, "启动活动检测计时器");
    }

    private void stopInactivityTimer() {
        handler.removeCallbacks(inactivityCheckRunnable);
        Log.d(TAG, "停止活动检测计时器");
    }

    private void resetInactivityTimer() {
        lastActivityTime = System.currentTimeMillis();
        Log.d(TAG, "重置活动检测计时器");
    }

    // 添加活动检测方法
    private void checkInactivity() {
        if (!isConnectionActive) return;

        long currentTime = System.currentTimeMillis();
        long inactiveDuration = currentTime - lastActivityTime;

        if (inactiveDuration >= INACTIVITY_THRESHOLD_DISCONNECT) {
            // 50秒无活动，断开连接
            Log.d(TAG, "50秒无活动，断开连接");
            disconnect();
            runOnUiThread(() -> {
                Toast.makeText(this, "50秒无活动，连接已断开", Toast.LENGTH_LONG).show();
            });
        }
    }

    private void setSpeakerMode(boolean speaker) {
        try {
            if (speaker) {
                audioManager.setMode(AudioManager.MODE_NORMAL);
                audioManager.setSpeakerphoneOn(true);
                // 设置扬声器音量为15%
                int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);
                int targetVolume = (int) (maxVolume * 0.15);
                audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, targetVolume, 0);
            } else {
                // 修复听筒模式设置
                audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                audioManager.setSpeakerphoneOn(false);
                // 确保使用正确的音频流类型，设置听筒音量为最大
                int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);
                audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, maxVolume, 0);
            }
        } catch (Exception e) {
            Log.e(TAG, "设置音频模式失败: " + e.getMessage());
            // 防止崩溃，显示错误提示
            runOnUiThread(() -> Toast.makeText(this, "音频模式切换失败", Toast.LENGTH_SHORT).show());
        }
    }

    // 设置状态
    @SuppressLint("MissingPermission")
    private void setState(int newState) {
        // 状态切换时增加计数器
        if (currentState != newState) {
            stateChangeCount++;
            Log.d(TAG, "状态切换计数: " + stateChangeCount);

            // 检查是否达到最大切换次数
            if (stateChangeCount >= MAX_STATE_CHANGES) {
                Log.d(TAG, "达到最大状态切换次数，将断开重连");
                stateChangeCount = 0; // 重置计数器

                // 播放提示音
                playConnectionSound();

                // 断开并重连
                if (lastConnectedDevice != null) {
                    disconnect();
                    handler.postDelayed(() -> {
                        connectToDevice(lastConnectedDevice);
                    }, 500); // 延迟500ms重连
                }
            }
        }
        currentState = newState;
        runOnUiThread(() -> {
            switch (newState) {
                case STATE_IDLE:
                    tvStatus.setText("已连接: " + (connectedThread != null ? connectedThread.socket.getRemoteDevice().getName() : ""));
                    btnTalk.setEnabled(true);
                    btnTalk.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_green_light));
                    // 确保音频模式切换按钮在空闲状态下启用
                    btnAudioMode.setEnabled(true);
                    if (!isTalkButtonDisabled){   btnTalk.setText("按下对讲");}
                    break;
                case STATE_TALKING:
                    tvStatus.setText("我方说话中");
                    btnAudioMode.setEnabled(false);
                    if(isTalkButtonDisabled){btnTalk.setText("作用中");}
                    else{
                        btnTalk.setText("对讲中,再次按下停止");
                        btnTalk.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_red_light));
                        // 在说话状态下禁用音频模式切换
                    }
                    break;
                case STATE_RECEIVING:
                    tvStatus.setText("对方说话中");
                    btnTalk.setEnabled(false);
                    btnTalk.setText("对方说话中");
                    btnTalk.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray));
                    // 在接收状态下禁用音频模式切换
                    btnAudioMode.setEnabled(false);
                    // 设置超时检测
                    handler.removeCallbacks(receiveTimeoutRunnable);
                    handler.postDelayed(receiveTimeoutRunnable, RECEIVE_TIMEOUT);
                    break;
            }
        });
    }

    private void startTalking() {
        if (!isConnectionActive || isRecording) return;

        Log.d(TAG, "开始说话");
        setState(STATE_TALKING);
        audioRecorderPlayer.startRecording();
        isRecording = true;
    }

    private void stopTalking() {
        if (!isRecording) return;
        Log.d(TAG, "停止说话");
        audioRecorderPlayer.stopRecording();
        isRecording = false;
        btnTalk.setText("作用中");
        setState(STATE_IDLE); // 这会重新启用音频模式切换按钮
    }

    // 新增方法：设置加载状态
    private void setLoadingState() {
        runOnUiThread(() -> {
            tvStatus.setText("加载中...");
            // 禁用所有控件
            deviceList.setEnabled(false);
            btnRefresh.setEnabled(false);
            btnAudioMode.setEnabled(false);
            btnTalk.setEnabled(false);
            btnDisconnect.setEnabled(false);
            btnPair.setEnabled(false);
        });
    }

    // 新增方法：设置初始状态
    private void setInitialState() {
        runOnUiThread(() -> {
            tvStatus.setText("未连接");
            // 重置所有按钮状态
            btnTalk.setEnabled(false);
            btnTalk.setText("按下对讲");
            btnTalk.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray));
            btnDisconnect.setEnabled(false);
            btnAudioMode.setEnabled(false);

            // 启用初始控件
            deviceList.setEnabled(true);
            btnRefresh.setEnabled(true);
            btnPair.setEnabled(true);

            refreshPairedDevices();
            startServer(); // 确保启动监听
        });
    }

    private void playConnectionSound() {
        // 使用振动代替铃声
        try {
            // 获取振动服务
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

            // 检查设备是否支持振动
            if (vibrator != null && vibrator.hasVibrator()) {
                // 创建振动模式：振动500ms
                long[] pattern = {0, 500}; // 延迟0ms，振动500ms

                // 使用兼容API进行振动
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Android 8.0+ 使用新的振动API
                    VibrationEffect effect = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE);
                    vibrator.vibrate(effect);
                } else {
                    // 旧版本使用传统方法
                    vibrator.vibrate(500);
                }
            } else {
                Log.d(TAG, "设备不支持振动");
            }
        } catch (Exception e) {
            Log.e(TAG, "振动失败: " + e.getMessage());
        }
    }

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                Log.d(TAG, "设备已连接: " + device.getName());
                tvStatus.setText("已连接: " + device.getName());
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                Log.d(TAG, "设备已断开: " + device.getName());
                handleConnectionLost();
            } else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                if (state == BluetoothAdapter.STATE_ON) {
                    refreshPairedDevices();
                    startServer();
                } else if (state == BluetoothAdapter.STATE_OFF) {
                    tvStatus.setText("蓝牙已关闭");
                }
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        refreshPairedDevices();
        startServer();
        handler.post(refreshRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refreshRunnable);
        handler.removeCallbacks(receiveTimeoutRunnable);
        if (isRecording) {
            stopTalking();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(bluetoothReceiver);
        } catch (Exception e) {
            Log.e(TAG, "取消注册广播接收器失败: " + e.getMessage());
        }

        // 先断开连接再释放资源
        disconnect();

        if (audioRecorderPlayer != null) {
            audioRecorderPlayer.release();
            audioRecorderPlayer = null;
        }

        // 移除所有回调
        handler.removeCallbacksAndMessages(null);
    }

    // 内部线程类
    private class AcceptThread extends Thread {
        private BluetoothServerSocket serverSocket;
        private boolean isRunning = true;

        @SuppressLint("MissingPermission")
        public AcceptThread() {
            try {
                if (hasBluetoothPermissions()) {
                    serverSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord(APP_NAME, MY_UUID);
                    Log.d(TAG, "服务器Socket创建成功");
                } else {
                    Log.e(TAG, "没有蓝牙权限");
                }
            } catch (IOException e) {
                Log.e(TAG, "创建服务器Socket失败: " + e.getMessage());
                try {
                    Method method = bluetoothAdapter.getClass().getMethod("listenUsingRfcommOn", int.class);
                    serverSocket = (BluetoothServerSocket) method.invoke(bluetoothAdapter, 1);
                    Log.d(TAG, "使用反射方法创建服务器Socket成功");
                } catch (Exception ex) {
                    Log.e(TAG, "反射方法也失败: " + ex.getMessage());
                }
            }
        }

        @SuppressLint("MissingPermission")
        public void run() {
            BluetoothSocket socket;
            while (isRunning) {
                try {
                    Log.d(TAG, "等待连接...");
                    socket = serverSocket.accept();
                    Log.d(TAG, "接收到连接");

                    if (socket != null) {
                        // 在主线程播放铃声
                        runOnUiThread(() -> playConnectionSound());
                        isIncomingConnection = true;
                        connected(socket);
                    }
                } catch (IOException e) {
                    Log.e(TAG, "接受连接失败: " + e.getMessage());
                    if (isRunning) {
                        try {
                            Thread.sleep(2000);
                            if (hasBluetoothPermissions()) {
                                serverSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord(APP_NAME, MY_UUID);
                                Log.d(TAG, "重新创建服务器Socket成功");
                            }
                        } catch (Exception ex) {
                            Log.e(TAG, "重启服务器失败: " + ex.getMessage());
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
        }

        public void cancel() {
            isRunning = false;
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                    Log.d(TAG, "服务器Socket已关闭");
                }
            } catch (IOException e) {
                Log.e(TAG, "关闭服务器Socket失败: " + e.getMessage());
            }
        }
    }

    private class ConnectThread extends Thread {
        private final BluetoothDevice device;
        private BluetoothSocket socket;
        private int retryCount = 0;
        private static final int MAX_RETRY = 8;
        private int currentMethod = 0;
        private static final long RETRY_DELAY_MS = 2000;

        @SuppressLint("MissingPermission")
        public ConnectThread(BluetoothDevice device) {
            this.device = device;
        }

        @SuppressLint("MissingPermission")
        public void run() {
            Log.d(TAG, "连接线程开始运行");

            if (!hasBluetoothPermissions()) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "蓝牙权限不足", Toast.LENGTH_SHORT).show();
                    isConnecting = false;
                });
                return;
            }

            if (bluetoothAdapter.isDiscovering()) {
                bluetoothAdapter.cancelDiscovery();
            }

            while (currentMethod < MAX_RETRY && !isInterrupted()) {
                try {
                    Log.d(TAG, "尝试方法 " + (currentMethod + 1) + ", 重试次数: " + (retryCount + 1));

                    socket = createSocketWithMethod(device, currentMethod);

                    if (socket == null) {
                        Log.e(TAG, "无法使用方法 " + (currentMethod + 1) + " 创建socket");
                        currentMethod++;
                        retryCount = 0;
                        continue;
                    }

                    socket.connect();
                    Log.d(TAG, "使用方法 " + (currentMethod + 1) + " 连接成功");

                    // 重要修改：不要立即取消连接线程
                    // 而是将 socket 传递给 connected() 方法
                    runOnUiThread(() -> connected(socket));
                    return;
                } catch (IOException e) {
                    retryCount++;
                    Log.e(TAG, "方法 " + (currentMethod + 1) + " 连接失败: " + e.getMessage());

                    try {
                        if (socket != null) {
                            socket.close();
                        }
                    } catch (IOException closeException) {
                        Log.e(TAG, "关闭socket失败: " + closeException.getMessage());
                    }

                    if (retryCount >= 1) {
                        currentMethod++;
                        retryCount = 0;
                    }

                    if (currentMethod >= MAX_RETRY) {
                        runOnUiThread(() -> {
                            Toast.makeText(MainActivity.this, "所有连接方法都失败", Toast.LENGTH_LONG).show();
                            tvStatus.setText("连接失败");
                            isConnecting = false;
                        });
                        return;
                    } else {
                        try {
                            Thread.sleep(RETRY_DELAY_MS);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            runOnUiThread(() -> isConnecting = false);
                            return;
                        }
                    }
                }
            }
        }

        @SuppressLint("MissingPermission")
        private BluetoothSocket createSocketWithMethod(BluetoothDevice device, int methodIndex) {
            try {
                switch (methodIndex) {
                    case 0:
                        return device.createRfcommSocketToServiceRecord(MY_UUID);
                    case 1:
                        return (BluetoothSocket) device.getClass()
                                .getMethod("createRfcommSocket", int.class)
                                .invoke(device, 1);
                    case 2:
                        return (BluetoothSocket) device.getClass()
                                .getMethod("createInsecureRfcommSocket", int.class)
                                .invoke(device, 1);
                    case 3:
                        UUID fallbackUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
                        return device.createRfcommSocketToServiceRecord(fallbackUuid);
                    case 4:
                        Method m = device.getClass().getMethod("createRfcommSocket", int.class);
                        return (BluetoothSocket) m.invoke(device, 1);
                    case 5:
                        UUID differentUuid = UUID.fromString("00001105-0000-1000-8000-00805F9B34FB");
                        return device.createRfcommSocketToServiceRecord(differentUuid);
                    case 6:
                        return device.createRfcommSocketToServiceRecord(MY_UUID);
                    case 7:
                        return device.createInsecureRfcommSocketToServiceRecord(MY_UUID);
                    default:
                        return null;
                }
            } catch (Exception e) {
                Log.e(TAG, "方法 " + (methodIndex + 1) + " 创建socket失败: " + e.getMessage());
                return null;
            }
        }

        public void cancel() {
            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                Log.e(TAG, "取消连接失败: " + e.getMessage());
            } finally {
                runOnUiThread(() -> isConnecting = false);
            }
        }
    }

    public class ConnectedThread extends Thread {
        private final BluetoothSocket socket;
        private final InputStream inputStream;
        private final OutputStream outputStream;
        private boolean isRunning = true;
        private ByteArrayOutputStream audioBuffer = new ByteArrayOutputStream();
        private static final int FIXED_PACKET_SIZE = 640; // 固定包大小
        private Context context; // 添加 Context 引用

        public ConnectedThread(BluetoothSocket socket, Context context) {
            this.socket = socket;
            this.context = context; // 保存 Context 引用
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
                Log.d(TAG, "输入输出流获取成功");
            } catch (IOException e) {
                Log.e(TAG, "获取输入输出流失败: " + e.getMessage());
                // 不要立即调用 handleConnectionLost()
                // 而是设置标志，在 run() 方法中处理
            }

            inputStream = tmpIn;
            outputStream = tmpOut;
        }

        public void run() {
            Log.d(TAG, "连接线程开始运行");

            if (inputStream == null || outputStream == null) {
                Log.e(TAG, "输入输出流无效，连接失败");
                handleConnectionLost();
                return;
            }

            byte[] buffer = new byte[AUDIO_BUFFER_SIZE];
            int bytes;

            Log.d(TAG, "开始读取音频数据");

            try {
                while (isRunning) {
                    try {
                        bytes = inputStream.read(buffer);
                        if (bytes > 0) {
                            Log.d(TAG, "接收到 " + bytes + " 字节数据");

                            // 将数据添加到缓冲区
                            audioBuffer.write(buffer, 0, bytes);

                            // 处理缓冲区中的数据
                            processAudioBuffer();
                        } else if (bytes == -1) {
                            Log.e(TAG, "输入流结束，连接已断开");
                            break;
                        }
                    } catch (IOException e) {
                        if (isRunning) {
                            Log.e(TAG, "读取数据时发生IO异常: " + e.getMessage());
                            break;
                        }
                    }
                }
            } finally {
                if (isRunning) {
                    handleConnectionLost();
                }
                Log.d(TAG, "连接线程结束");
                isConnectionActive = false;
            }
        }

        private void processAudioBuffer() {
            byte[] data = audioBuffer.toByteArray();
            int available = data.length;

            // 当有足够数据时处理
            while (available >= FIXED_PACKET_SIZE) {
                // 提取一个完整的数据包
                byte[] packet = new byte[FIXED_PACKET_SIZE];
                System.arraycopy(data, 0, packet, 0, FIXED_PACKET_SIZE);

                // 更新状态为接收中
                setState(STATE_RECEIVING);

                // 播放音频
                audioRecorderPlayer.playAudio(packet, FIXED_PACKET_SIZE);

                // 移除已处理的数据
                byte[] remaining = new byte[available - FIXED_PACKET_SIZE];
                System.arraycopy(data, FIXED_PACKET_SIZE, remaining, 0, remaining.length);

                // 更新缓冲区和可用数据
                audioBuffer.reset();
                audioBuffer.write(remaining, 0, remaining.length);
                data = remaining;
                available = data.length;

                // 使用保存的 context 引用
                if (context != null) {
                    ((MainActivity) context).resetInactivityTimer();
                }
            }
        }

        public void write(byte[] buffer) {
            try {
                outputStream.write(buffer);
                Log.d(TAG, "发送 " + buffer.length + " 字节数据");
            } catch (IOException e) {
                Log.e(TAG, "发送数据失败: " + e.getMessage());
                handleConnectionLost();
            }
        }

        public void cancel() {
            isRunning = false;
            isConnectionActive = false;
            try {
                if (socket != null) {
                    socket.close();
                    Log.d(TAG, "Socket已关闭");
                }
            } catch (IOException e) {
                Log.e(TAG, "关闭Socket失败: " + e.getMessage());
            } finally {
                runOnUiThread(() -> isConnecting = false);
            }
        }
    }

    private boolean hasBluetoothPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED;
    }
}