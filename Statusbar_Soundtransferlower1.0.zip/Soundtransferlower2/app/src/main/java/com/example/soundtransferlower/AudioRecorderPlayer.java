package com.example.soundtransferlower;

import android.annotation.SuppressLint;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AudioRecorderPlayer {
    private static final String TAG = "AudioRecorderPlayer";
    private static final int SAMPLE_RATE = 8000;
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int BUFFER_SIZE = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);

    private AudioRecord audioRecord;
    private AudioTrack audioTrack;
    private volatile boolean isRecording = false;
    private volatile boolean isPlaying = false;

    // 使用单线程执行器确保顺序播放
    private final ExecutorService playbackExecutor = Executors.newSingleThreadExecutor();

    public interface AudioDataSender {
        void sendAudioData(byte[] data);
    }

    private AudioDataSender audioDataSender;

    public AudioRecorderPlayer(MainActivity context) {
        initAudio();
    }

    public void setAudioDataSender(AudioDataSender sender) {
        this.audioDataSender = sender;
    }

    @SuppressLint("MissingPermission")
    private void initAudio() {
        try {
            audioRecord = new AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    BUFFER_SIZE * 2);

            audioTrack = new AudioTrack(
                    android.media.AudioManager.STREAM_VOICE_CALL,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AUDIO_FORMAT,
                    BUFFER_SIZE * 2,
                    AudioTrack.MODE_STREAM);

            Log.d(TAG, "音频录制和播放初始化成功");
        } catch (Exception e) {
            Log.e(TAG, "音频初始化失败: " + e.getMessage());
        }
    }

    public void startRecording() {
        if (audioRecord == null || isRecording) return;

        Log.d(TAG, "开始录音");
        new Thread(() -> {
            try {
                audioRecord.startRecording();
                isRecording = true;
                Log.d(TAG, "录音已启动");
                // 使用固定大小的缓冲区
                int fixedBufferSize = 640; // 固定为640字节
                byte[] buffer = new byte[fixedBufferSize];

                while (isRecording) {
                    int totalRead = 0;
                    // 循环读取直到填满缓冲区
                    while (totalRead < fixedBufferSize) {
                        int bytesRead = audioRecord.read(buffer, totalRead, fixedBufferSize - totalRead);
                        if (bytesRead <= 0) break;
                        totalRead += bytesRead;
                    }

                    if (totalRead > 0 && audioDataSender != null) {
                        // 只发送完整的数据包
                        if (totalRead == fixedBufferSize) {
                            Log.d(TAG, "录制到 " + totalRead + " 字节数据");
                            audioDataSender.sendAudioData(buffer);
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "录制错误: " + e.getMessage());
            } finally {
                stopRecordingInternal();
                Log.d(TAG, "录音线程结束");
            }
        }).start();
    }

    public void stopRecording() {
        if (isRecording) {
            isRecording = false;
        }
    }

    private void stopRecordingInternal() {
        if (audioRecord != null && audioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
            Log.d(TAG, "停止录音");
            audioRecord.stop();
            Log.d(TAG, "录音已停止");
        }
    }

    public void playAudio(byte[] data, int length) {
        if (audioTrack == null || length <= 0) return;

        playbackExecutor.execute(() -> {
            try {
                if (audioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioTrack未初始化");
                    return;
                }

                if (audioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                    audioTrack.play();
                    isPlaying = true;
                    Log.d(TAG, "音频播放已启动");
                }

                // 兼容低版本：计算缓冲区大小
                int bufferSize;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    // Android 6.0+ 使用 getBufferSizeInFrames()
                    bufferSize = audioTrack.getBufferSizeInFrames() * 2; // 每帧2字节（16位）
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    // Android 5.0+ 使用 getBufferSizeInBytes()
                    bufferSize = BUFFER_SIZE * 2;
                } else {
                    // Android 4.4 及以下版本使用固定缓冲区大小
                    bufferSize = BUFFER_SIZE * 2; // 使用初始化时设置的缓冲区大小
                }

                Log.d(TAG, "播放音频数据，长度: " + length + ", 缓冲区大小: " + bufferSize);

                int written = 0;
                while (written < length) {
                    int bytesToWrite = Math.min(bufferSize, length - written);
                    int result = audioTrack.write(data, written, bytesToWrite);

                    if (result > 0) {
                        written += result;
                    } else {
                        Log.e(TAG, "AudioTrack写入错误: " + result);
                        break;
                    }
                }

                Log.d(TAG, "成功播放音频数据，长度: " + length);
            } catch (Exception e) {
                Log.e(TAG, "播放错误: " + e.getMessage());
            }
        });
    }

    public void release() {
        stopRecording();
        isPlaying = false;

        playbackExecutor.shutdownNow();

        if (audioRecord != null) {
            stopRecordingInternal();
            audioRecord.release();
            audioRecord = null;
        }

        if (audioTrack != null) {
            if (audioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                audioTrack.stop();
            }
            audioTrack.release();
            audioTrack = null;
        }

        Log.d(TAG, "音频资源已释放");
    }
}