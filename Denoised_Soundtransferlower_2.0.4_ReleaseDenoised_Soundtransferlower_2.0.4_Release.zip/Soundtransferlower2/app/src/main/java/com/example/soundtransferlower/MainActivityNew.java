package com.example.soundtransferlower;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.PopupMenu;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

public class MainActivityNew extends FragmentActivity implements BluetoothService.MessageCallback {
    private ImageButton btnBack;
    private ImageButton btnMenu;
    private BluetoothFinder bluetoothFinder;
    private boolean isFirstLaunch = true;
    private Handler handler = new Handler();
    private AlertDialog deviceSelectionDialog;
    private ArrayAdapter<String> deviceAdapter;
    private List<BluetoothDevice> availableDevices = new ArrayList<>();
    private List<String> deviceNames = new ArrayList<>();
    // 添加状态显示TextView
    private TextView mainStatus;
    private TextView emptyHint; // 新增：空容器提示文本

    private static final String TAG = "MainActivityNew";
    private BluetoothAdapter bluetoothAdapter;
    private List<BluetoothDevice> pairedDevices = new ArrayList<>();
    private boolean isSpeakerMode = false;

    // 蓝牙服务相关
    private BluetoothService bluetoothService;
    private boolean serviceBound = false;

    // 添加连接状态跟踪
    private int currentConnectionState = BluetoothService.STATE_NONE;
    private String connectedDeviceName = "";
    private int currentMode = BluetoothService.MODE_CHAT;

    // 添加变量来跟踪当前连接的设备地址
    private String connectedDeviceAddress = "";

    // 添加标志来跟踪广播接收器是否已注册
    private boolean isReceiverRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_new);

        // 初始化状态显示TextView
        mainStatus = findViewById(R.id.mainStatus);
        // 初始化空容器提示文本
        emptyHint = findViewById(R.id.emptyHint);
        updateStatusDisplay();
        updateEmptyHintVisibility(); // 初始时更新提示可见性

        // 初始化蓝牙发现器
        bluetoothFinder = new BluetoothFinder(this);

        // 初始化顶部工具栏按钮
        btnBack = findViewById(R.id.btnBack);
        btnMenu = findViewById(R.id.btnMenu);

        // 设置返回键点击事件
        btnBack.setOnClickListener(v -> {
            // 如果当前有Fragment在回退栈中，则弹出
            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                getSupportFragmentManager().popBackStack();
                updateEmptyHintVisibility(); // 更新提示可见性
            } else {
                // 否则退出应用
                finish();
            }
        });

        // 设置菜单键点击事件
        btnMenu.setOnClickListener(v -> {
            // 创建并显示PopupMenu
            showPopupMenu(v);
        });

        Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(intent);
        // 初始化蓝牙适配器
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "蓝牙不可用", Toast.LENGTH_SHORT).show();
            finish();
        }

        // 启动并绑定蓝牙服务
        Intent serviceIntent = new Intent(this, BluetoothService.class);
        startService(serviceIntent);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        // 加载初始Fragment - 默认加载聊天工作Fragment
        Intent intent1 = getIntent();
        if (intent1 != null && intent1.hasExtra("LOAD_FRAGMENT")) {
            String fragmentName = intent1.getStringExtra("LOAD_FRAGMENT");
            if ("TalkbackFragment".equals(fragmentName)) {
                loadFragment(new ChatWorkFragment());
                currentMode = BluetoothService.MODE_CHAT;
                updateStatusDisplay();
            }
        } else {
            // 默认加载对讲Fragment
            loadFragment(new ChatWorkFragment());
            currentMode = BluetoothService.MODE_CHAT;
            updateStatusDisplay();
        }

        // 设置底部按钮点击事件
        Button btnTalkback = findViewById(R.id.btnTalkback);
        Button btnChat = findViewById(R.id.btnChat);
        Button btnMine = findViewById(R.id.btnMine);

        // 修改底部按钮点击事件
        btnTalkback.setOnClickListener(v -> {
            // 清除回退栈并加载对讲Fragment
            clearBackStack();
            loadFragment(new TalkbackFragment());
            currentMode = BluetoothService.MODE_TALKBACK;
            updateStatusDisplay();
        });

        btnChat.setOnClickListener(v -> {
            // 清除回退栈并加载聊天Fragment
            clearBackStack();
            loadFragment(new ChatFragment());
            currentMode = BluetoothService.MODE_CHAT;
            updateStatusDisplay();
        });

        btnMine.setOnClickListener(v -> {
            // 清除回退栈并加载我的Fragment
            clearBackStack();
            loadFragment(new MineFragment());
            updateStatusDisplay();
        });

        // 设置Fragment回退栈变化监听器
        getSupportFragmentManager().addOnBackStackChangedListener(() -> {
            updateEmptyHintVisibility();
        });

        // 延迟显示设备选择对话框，确保UI已加载完成
        handler.postDelayed(() -> {
            if (isFirstLaunch && serviceBound) {
                showDeviceSelectionDialog();
                isFirstLaunch = false;
            }
        }, 1000);
    }

    // 新增：更新空容器提示可见性
    private void updateEmptyHintVisibility() {
        if (getSupportFragmentManager().getBackStackEntryCount() == 0) {
            emptyHint.setVisibility(View.VISIBLE);
        } else {
            emptyHint.setVisibility(View.GONE);
        }
    }

    // 添加状态显示更新方法
    private void updateStatusDisplay() {
        runOnUiThread(() -> {
            if (mainStatus == null) {
                return;
            }

            String statusText = "";
            switch (currentConnectionState) {
                case BluetoothService.STATE_NONE:
                    statusText = "未连接";
                    break;
                case BluetoothService.STATE_LISTEN:
                    if (currentMode == BluetoothService.MODE_CHAT) {
                        statusText = "等待文本连接...";
                    } else {
                        statusText = "等待对讲连接...";
                    }
                    break;
                case BluetoothService.STATE_CONNECTING:
                    if (currentMode == BluetoothService.MODE_CHAT) {
                        statusText = "文本连接中...";
                    } else {
                        statusText = "对讲连接中...";
                    }
                    break;
                case BluetoothService.STATE_CONNECTED:
                    if (currentMode == BluetoothService.MODE_CHAT) {
                        statusText = "文本接入: " + connectedDeviceName;
                    } else {
                        statusText = "语音接入: " + connectedDeviceName;
                    }
                    break;
            }

            mainStatus.setText(statusText);
        });
    }

    // 显示设备选择对话框（修改后的版本）
    private void showDeviceSelectionDialog() {
        // 清空设备列表
        availableDevices.clear();
        deviceNames.clear();

        // 创建适配器（初始为空）
        deviceAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                deviceNames
        );

        // 创建对话框 - 使用自定义主题
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("请先稍等，选择文本连接目标设备");
        builder.setAdapter(deviceAdapter, (dialog, which) -> {
            BluetoothDevice selectedDevice = availableDevices.get(which);
            connectToDeviceForChatAndNavigate(selectedDevice);
        });


        // 添加直接进入按钮
        builder.setNeutralButton("直接进入", (dialog, which) -> {
            // 停止扫描
            stopScanSafely();
            // 取消注册广播接收器
            safeUnregisterReceiver();
            // 移除所有Handler回调
            handler.removeCallbacksAndMessages(null);
            // 清除回退栈并加载空Fragment
            clearBackStack();
            loadFragment(new ChatWorkFragment());
            // 更新状态显示
            currentConnectionState = BluetoothService.STATE_NONE;
            updateStatusDisplay();
            // 标记不再显示对话框
            isFirstLaunch = false;
        });


        // 初始时不显示取消按钮
        builder.setNegativeButton("取消", null);
        builder.setCancelable(false);
        // 设置对话框关闭监听器
        builder.setOnDismissListener(dialog -> {
            deviceSelectionDialog = null;
            // 停止扫描
            stopScanSafely();
            // 取消注册广播接收器
            safeUnregisterReceiver();
            // 移除所有Handler回调
            handler.removeCallbacksAndMessages(null);
        });

        // 显示对话框（此时列表为空）
        deviceSelectionDialog = builder.create();
        deviceSelectionDialog.show();

        // 初始时禁用取消按钮
        deviceSelectionDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setEnabled(false);

        // 开始扫描过程
        startDeviceScanning();
    }
    private void stopScanSafely() {
        try {
            if (bluetoothFinder != null) {
                bluetoothFinder.stopScan();
            }
        } catch (Exception e) {
            Log.e(TAG, "安全停止扫描时出错: " + e.getMessage());
        }
    }
    // 安全取消注册广播接收器的方法
    private void safeUnregisterReceiver() {
        if (isReceiverRegistered) {
            try {
                unregisterReceiver(deviceDiscoveryReceiver);
                isReceiverRegistered = false;
            } catch (IllegalArgumentException e) {
                // 如果接收器未注册，忽略异常
                Log.w(TAG, "接收器未注册: " + e.getMessage());
            }
        }
    }

    // 处理扫描到的设备
    private void processAvailableDevices() {
        ArrayList<BluetoothDevice> availableDevices = bluetoothFinder.getDuplicateDevices();

        if (availableDevices.isEmpty()) {
            Toast.makeText(this, "没有找到附近已配对的设备", Toast.LENGTH_SHORT).show();
            return;
        }

        // 创建设备列表对话框
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("请先稍等，选择文本连接目标设备");

        // 创建设备名称列表
        final List<String> deviceNames = new ArrayList<>();
        for (BluetoothDevice device : availableDevices) {
            // 排除当前正在连接的设备
            if (!device.getAddress().equals(connectedDeviceAddress)) {
                String name = device.getName();
                if (name == null || name.isEmpty()) {
                    name = "未知设备 (" + device.getAddress() + ")";
                }
                deviceNames.add(name);
            }
        }

        // 使用数组适配器创建列表
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                deviceNames
        );

        builder.setAdapter(adapter, (dialog, which) -> {
            BluetoothDevice selectedDevice = availableDevices.get(which);
            // 修改：直接跳转到ChatWorkFragment并传递设备信息
            connectToDeviceForChatAndNavigate(selectedDevice);
        });

        builder.setNegativeButton("取消", null);
        builder.setCancelable(false);
        builder.show();
    }

    // 新增方法：连接到设备并导航到ChatWorkFragment
    private void connectToDeviceForChatAndNavigate(BluetoothDevice device) {
        if (!serviceBound || bluetoothService == null) {
            Toast.makeText(this, "蓝牙服务未就绪", Toast.LENGTH_SHORT).show();
            return;
        }

        // 设置文本模式
        bluetoothService.setMode(BluetoothService.MODE_CHAT);
        currentMode = BluetoothService.MODE_CHAT;

        // 基于设备地址的角色分配算法
        String localAddress = bluetoothAdapter.getAddress();
        String remoteAddress = device.getAddress();
        boolean isInitiator = localAddress.compareTo(remoteAddress) > 0;

        // 设置连接角色并连接
        bluetoothService.setConnectionRole(isInitiator, remoteAddress);

        if (isInitiator) {
            Toast.makeText(this, "正在连接 " + device.getName(), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "等待 " + device.getName() + " 连接", Toast.LENGTH_SHORT).show();
        }

        // 更新状态显示
        connectedDeviceName = device.getName();
        connectedDeviceAddress = device.getAddress();
        currentConnectionState = BluetoothService.STATE_CONNECTING;
        updateStatusDisplay();

        // 创建ChatWorkFragment并传递设备信息
        ChatWorkFragment chatWorkFragment = new ChatWorkFragment();
        Bundle args = new Bundle();
        args.putString("DEVICE_ADDRESS", device.getAddress());
        args.putString("DEVICE_NAME", device.getName());
        chatWorkFragment.setArguments(args);

        // 加载ChatWorkFragment
        clearBackStack();
        loadFragment(chatWorkFragment);
    }

    // 连接到选定的设备进行文本聊天
    private void connectToDeviceForChat(BluetoothDevice device) {
        if (!serviceBound || bluetoothService == null) {
            Toast.makeText(this, "蓝牙服务未就绪", Toast.LENGTH_SHORT).show();
            return;
        }

        // 设置文本模式
        bluetoothService.setMode(BluetoothService.MODE_CHAT);
        currentMode = BluetoothService.MODE_CHAT;

        // 基于设备地址的角色分配算法
        String localAddress = bluetoothAdapter.getAddress();
        String remoteAddress = device.getAddress();
        boolean isInitiator = localAddress.compareTo(remoteAddress) > 0;

        // 设置连接角色并连接
        bluetoothService.setConnectionRole(isInitiator, remoteAddress);

        if (isInitiator) {
            Toast.makeText(this, "正在连接 " + device.getName(), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "等待 " + device.getName() + " 连接", Toast.LENGTH_SHORT).show();
        }

        // 更新状态显示
        connectedDeviceName = device.getName();
        connectedDeviceAddress = device.getAddress();
        currentConnectionState = BluetoothService.STATE_CONNECTING;
        updateStatusDisplay();

        // 创建ChatWorkFragment并传递设备信息
        ChatWorkFragment chatWorkFragment = new ChatWorkFragment();
        Bundle args = new Bundle();
        args.putString("DEVICE_ADDRESS", device.getAddress());
        args.putString("DEVICE_NAME", device.getName());
        chatWorkFragment.setArguments(args);

        // 加载ChatWorkFragment
        clearBackStack();
        loadFragment(chatWorkFragment);
    }

    // 服务连接
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BluetoothService.LocalBinder binder = (BluetoothService.LocalBinder) service;
            bluetoothService = binder.getService();
            bluetoothService.registerCallback(MainActivityNew.this);
            serviceBound = true;

            // 启动服务监听
            bluetoothService.start();

            // 更新连接状态显示
            int state = bluetoothService.getState();
            String deviceName = ""; // 这里没有特定的设备名称，使用空字符串
            onConnectionStatusChanged(state, deviceName);

            // 如果这是第一次启动，显示设备选择对话框
            if (isFirstLaunch) {
                showDeviceSelectionDialog();
                isFirstLaunch = false;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 解绑服务
        if (serviceBound) {
            if (bluetoothService != null) {
                bluetoothService.unregisterCallback(this);
            }
            unbindService(serviceConnection);
            serviceBound = false;
        }

        // 停止蓝牙扫描
        if (bluetoothFinder != null) {
            bluetoothFinder.stopScan();
        }

        // 安全取消注册广播接收器
        safeUnregisterReceiver();

        // 移除所有Handler回调
        handler.removeCallbacksAndMessages(null);
    }

    // 实现MessageCallback接口方法
    @Override
    public void onMessageReceived(String message, String deviceAddress) {
        // 创建新的不可变变量
        final String displayMessage = message.startsWith("TXT:") ? message.substring(4) : message;

        // 在主界面收到消息，显示通知
        runOnUiThread(() -> {
            Toast.makeText(this, "收到新消息: " + displayMessage, Toast.LENGTH_SHORT).show();

            // 如果当前在聊天Fragment，刷新设备列表显示未读消息
            Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
            if (currentFragment instanceof ChatFragment) {
                ((ChatFragment) currentFragment).refreshDeviceList();
            }

            // 无论当前在哪个Fragment，都尝试保存消息到聊天记录
            saveMessageToChatHistory(displayMessage, deviceAddress);
        });
    }

    // 保存消息到聊天记录
    private void saveMessageToChatHistory(String message, String deviceAddress) {
        // 这里实现保存消息到文件的逻辑
        // 可以使用与BluetoothService中相同的保存方法
        try {
            String filename = "chat_" + deviceAddress.replace(":", "_") + ".txt";
            File file = new File(getExternalFilesDir(null), filename);

            if (!file.exists()) {
                file.createNewFile();
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String timestamp = sdf.format(new Date());

            FileOutputStream fos = new FileOutputStream(file, true);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(timestamp + ": " + message + "\n");
            osw.close();
        } catch (IOException e) {
            Log.e(TAG, "Error saving message to file", e);
        }
    }

    @Override
    public void onConnectionStatusChanged(int state, String deviceName) {
        runOnUiThread(() -> {
            currentConnectionState = state;
            if (deviceName != null && !deviceName.isEmpty()) {
                connectedDeviceName = deviceName;
            }

            updateStatusDisplay();

            // 新增：如果状态变为已连接，并且设备选择对话框正在显示，则关闭对话框
            if (state == BluetoothService.STATE_CONNECTED) {
                if (deviceSelectionDialog != null && deviceSelectionDialog.isShowing()) {
                    deviceSelectionDialog.dismiss();
                }
            }
        });
    }

    // 新增对讲数据回调，主活动不需要处理，所以空实现
    @Override
    public void onTalkbackDataReceived(byte[] data, String deviceAddress) {
        // 主活动不处理对讲数据
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true; // 直接返回 true
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_pair) {
            // ...原有代码
        } else if (id == R.id.menu_refresh) {
            refreshPairedDevices();
            return true;
        } else if (id == R.id.menu_select_device) { // 使用资源文件中的ID
            showDeviceSelectionDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void toggleSpeakerMode() {
        isSpeakerMode = !isSpeakerMode;
        Toast.makeText(this, isSpeakerMode ? "已开启外放" : "已关闭外放", Toast.LENGTH_SHORT).show();
    }

    @SuppressLint("MissingPermission")
    public void refreshPairedDevices() {
        if (bluetoothAdapter == null) return;

        Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
        pairedDevices.clear();
        pairedDevices.addAll(devices);

        if (deviceAdapter != null) {
            deviceAdapter.notifyDataSetChanged();
        }

        Log.d(TAG, "刷新配对设备列表，数量: " + pairedDevices.size());
    }

    private void loadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null); // 添加到回退栈，以便可以返回
        transaction.commit();
        updateEmptyHintVisibility(); // 更新提示可见性
    }

    public List<BluetoothDevice> getPairedDevices() {
        return pairedDevices;
    }

    // 聊天Fragment - 改为public static
    public static class ChatFragment extends Fragment {
        private DeviceListAdapter deviceAdapter;
        private MainActivityNew mainActivity;

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_chat, container, false);

            TextView tvTitle = view.findViewById(R.id.tvBluetoothDevices);
            ListView listView = view.findViewById(R.id.deviceListView);

            // 获取主Activity实例
            mainActivity = (MainActivityNew) getActivity();
            if (mainActivity == null) return view;

            // 初始化适配器
            deviceAdapter = new DeviceListAdapter(getActivity(), R.layout.item_main, mainActivity.getPairedDevices());
            listView.setAdapter(deviceAdapter);

            // 刷新设备列表
            mainActivity.refreshPairedDevices();

            // 设置点击事件
            listView.setOnItemClickListener((parent, view1, position, id) -> {
                BluetoothDevice device = mainActivity.getPairedDevices().get(position);
                if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
                    mainActivity.connectToDeviceForChat(device);
                } else {
                    // 未配对设备 - 触发配对
                    pairDevice(device);
                }
            });

            return view;
        }

        // 刷新设备列表
        public void refreshDeviceList() {
            if (deviceAdapter != null && mainActivity != null) {
                deviceAdapter.notifyDataSetChanged();
            }
        }

        @SuppressLint("MissingPermission")
        private void pairDevice(BluetoothDevice device) {
            try {
                Method method = device.getClass().getMethod("createBond");
                method.invoke(device);
                Toast.makeText(getActivity(), "正在配对: " + device.getName(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "配对失败: " + e.getMessage());
                Toast.makeText(getActivity(), "配对失败", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // 我的Fragment - 改为public static
    public static class MineFragment extends Fragment {

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_mine, container, false);

            Button btnName = view.findViewById(R.id.btnName);
            Button btnAbout = view.findViewById(R.id.btnAbout);

            btnName.setOnClickListener(v -> showNameDialog());
            btnAbout.setOnClickListener(v -> showAboutDialog());

            return view;
        }

        private void showNameDialog() {
            // 使用自定义主题
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.CustomDialogTheme);
            builder.setTitle("修改蓝牙名称");

            // 获取当前蓝牙名称
            MainActivityNew mainActivity = (MainActivityNew) getActivity();
            String currentName = "";
            if (mainActivity != null && mainActivity.bluetoothAdapter != null) {
                currentName = mainActivity.bluetoothAdapter.getName();
            }

            // 创建包含当前名称的视图
            LinearLayout layout = new LinearLayout(getActivity());
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(50, 30, 50, 10);

            // 添加当前名称文本视图（可复制）
            TextView tvCurrentName = new TextView(getActivity());
            tvCurrentName.setText("当前名称: " + currentName);
            tvCurrentName.setTextSize(16);
            tvCurrentName.setTextIsSelectable(true); // 允许复制
            layout.addView(tvCurrentName);

            // 添加间距
            View space = new View(getActivity());
            space.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 20));
            layout.addView(space);

            // 添加编辑框
            final EditText input = new EditText(getActivity());
            input.setText(currentName); // 显示当前名称
            input.setHint("输入新名称");
            input.setSelectAllOnFocus(true); // 获取焦点时全选
            layout.addView(input);

            builder.setView(layout);

            builder.setPositiveButton("确认", (dialog, which) -> {
                String newName = input.getText().toString();
                if (!newName.isEmpty()) {
                    setBluetoothName(newName);
                }
            });

            builder.setNegativeButton("取消", (dialog, which) -> dialog.cancel());
            builder.show();
        }

        @SuppressLint("MissingPermission")
        private void setBluetoothName(String name) {
            MainActivityNew mainActivity = (MainActivityNew) getActivity();
            if (mainActivity != null && mainActivity.bluetoothAdapter != null) {
                mainActivity.bluetoothAdapter.setName(name);
                Toast.makeText(getActivity(), "蓝牙名称已修改", Toast.LENGTH_SHORT).show();
            }
        }

        private void showAboutDialog() {
            // 使用自定义主题
            new AlertDialog.Builder(getActivity(), R.style.CustomDialogTheme)
                    .setTitle("关于")
                    .setMessage(R.string.about)
                    .setPositiveButton("确定", null)
                    .show();
        }
    }

    // 设备列表适配器
    public static class DeviceListAdapter extends ArrayAdapter<BluetoothDevice> {

        private final LayoutInflater inflater;
        private final int resource;
        private final Context context;

        public DeviceListAdapter(Context context, int resource, List<BluetoothDevice> devices) {
            super(context, resource, devices);
            this.context = context;
            this.inflater = LayoutInflater.from(context);
            this.resource = resource;
        }

        @SuppressLint("MissingPermission")
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = inflater.inflate(resource, parent, false);
            }

            BluetoothDevice device = getItem(position);
            if (device != null) {
                TextView deviceName = convertView.findViewById(R.id.deviceName);
                TextView deviceAddress = convertView.findViewById(R.id.deviceAddress);
                TextView avatar = convertView.findViewById(R.id.avatar);

                String name = device.getName();
                if (name == null || name.isEmpty()) {
                    name = "未知设备";
                }
                deviceName.setText(name);
                deviceAddress.setText(device.getAddress());

                // 设置颜色
                int textColor = device.getBondState() == BluetoothDevice.BOND_BONDED ?
                        context.getResources().getColor(android.R.color.black) :
                        context.getResources().getColor(android.R.color.darker_gray);

                deviceName.setTextColor(textColor);
                deviceAddress.setTextColor(context.getResources().getColor(android.R.color.darker_gray));
                avatar.setText("蓝牙");
            }

            return convertView;
        }
    }


    private void startDeviceScanning() {
        // 获取已配对设备
        bluetoothFinder.fetchPairedDevices();

        // 注册设备发现广播接收器
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        try {
            registerReceiver(deviceDiscoveryReceiver, filter);
            isReceiverRegistered = true;
        } catch (Exception e) {
            Log.e(TAG, "注册接收器时出错: " + e.getMessage());
        }

        // 延迟500ms后开始扫描
        handler.postDelayed(() -> {
            // 第一次扫描
            startScanSafely();
            handler.postDelayed(() -> {
                stopScanSafely();

                // 间隔100ms后进行第二次扫描
                handler.postDelayed(() -> {
                    startScanSafely();
                    handler.postDelayed(() -> {
                        stopScanSafely();

                        // 在扫描完成后添加取消按钮
                        if (deviceSelectionDialog != null && deviceSelectionDialog.isShowing()) {
                            // 移除现有的按钮监听器
                            deviceSelectionDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(null);

                            // 设置新的取消按钮
                            deviceSelectionDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener(v -> {
                                deviceSelectionDialog.dismiss();
                            });

                            // 启用取消按钮
                            deviceSelectionDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setEnabled(true);
                        }

                        // 延迟3秒后关闭对话框
                        handler.postDelayed(() -> {
                            if (deviceSelectionDialog != null && deviceSelectionDialog.isShowing()) {
                                deviceSelectionDialog.dismiss();
                                if (availableDevices.isEmpty()) {
                                    Toast.makeText(MainActivityNew.this, "没有找到附近已配对的设备", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }, 3000); // 延迟3秒关闭
                    }, 3000); // 第二次扫描持续3秒
                }, 100); // 间隔100ms
            }, 6000); // 第一次扫描持续6秒
        }, 500); // 初始延迟500ms
    }
    private void startScanSafely() {
        try {
            if (bluetoothFinder != null) {
                bluetoothFinder.startScan();
            }
        } catch (Exception e) {
            Log.e(TAG, "安全启动扫描时出错: " + e.getMessage());
        }
    }
    private final BroadcastReceiver deviceDiscoveryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) {
                    // 检查设备是否已配对
                    if (bluetoothFinder.getPairedDevices().contains(device)) {
                        // 排除当前正在连接的设备
                        if (!device.getAddress().equals(connectedDeviceAddress)) {
                            // 添加到设备列表（去重）
                            if (!availableDevices.contains(device)) {
                                availableDevices.add(device);

                                String name = device.getName();
                                if (name == null || name.isEmpty()) {
                                    name = "未知设备 (" + device.getAddress() + ")";
                                }
                                deviceNames.add(name);

                                // 更新列表适配器
                                if (deviceAdapter != null) {
                                    runOnUiThread(() -> deviceAdapter.notifyDataSetChanged());
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    private void showPopupMenu(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.getMenuInflater().inflate(R.menu.main_menu, popup.getMenu()); // 加载完整菜单
        popup.setOnMenuItemClickListener(this::onOptionsItemSelected);
        popup.show();
    }

    private void coordinateConnection(BluetoothDevice device) {
        if (!serviceBound || bluetoothService == null) {
            Toast.makeText(this, "蓝牙服务未就绪", Toast.LENGTH_SHORT).show();
            return;
        }

        // 设置文本模式
        bluetoothService.setMode(BluetoothService.MODE_CHAT);
        currentMode = BluetoothService.MODE_CHAT;

        // 基于设备地址的简单角色分配算法
        String localAddress = bluetoothAdapter.getAddress();
        String remoteAddress = device.getAddress();

        boolean isInitiator = localAddress.compareTo(remoteAddress) > 0;
        bluetoothService.setConnectionRole(isInitiator, remoteAddress);

        if (isInitiator) {
            Toast.makeText(this, "正在连接 " + device.getName(), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "等待 " + device.getName() + " 连接", Toast.LENGTH_SHORT).show();
        }

        // 更新状态显示
        connectedDeviceName = device.getName();
        connectedDeviceAddress = device.getAddress();
        currentConnectionState = BluetoothService.STATE_CONNECTING;
        updateStatusDisplay();
    }

    private void clearBackStack() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        if (fragmentManager.getBackStackEntryCount() > 0) {
            FragmentManager.BackStackEntry first = fragmentManager.getBackStackEntryAt(0);
            fragmentManager.popBackStack(first.getId(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        updateEmptyHintVisibility(); // 更新提示可见性
    }
    // 在 MainActivityNew 类中添加以下方法：
    public void switchToFragment(String fragmentType, String deviceAddress, String deviceName) {
        // 断开当前连接
        if (bluetoothService != null) {
            bluetoothService.stop();
        }

        // 加载指定的Fragment
        Fragment fragment = null;
        if ("TalkbackFragment".equals(fragmentType)) {
            fragment = new TalkbackFragment();
            currentMode = BluetoothService.MODE_TALKBACK;
        } else if ("ChatWorkFragment".equals(fragmentType)) {
            fragment = new ChatWorkFragment();
            currentMode = BluetoothService.MODE_CHAT;
        }

        if (fragment != null) {
            // 传递设备信息
            Bundle args = new Bundle();
            args.putString("DEVICE_ADDRESS", deviceAddress);
            args.putString("DEVICE_NAME", deviceName);
            fragment.setArguments(args);

            // 清除回退栈并加载Fragment
            clearBackStack();
            loadFragment(fragment);

            // 重新连接设备
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
            if (bluetoothService != null) {
                // 基于设备地址的角色分配算法
                String localAddress = bluetoothAdapter.getAddress();
                String remoteAddress = deviceAddress;
                boolean isInitiator = localAddress.compareTo(remoteAddress) > 0;
                bluetoothService.setConnectionRole(isInitiator, remoteAddress);
            }
        }
        updateStatusDisplay();
    }
    @Override
    public void onNonTextDataReceived(String deviceAddress) {
        runOnUiThread(() -> {
            // 获取设备名称
            String deviceName = "未知设备";
            if (deviceAddress.equals(connectedDeviceAddress)) {
                deviceName = connectedDeviceName;
            } else {
                // 尝试通过蓝牙适配器获取设备名称
                try {
                    BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
                    if (device != null) {
                        deviceName = device.getName();
                        if (deviceName == null || deviceName.isEmpty()) {
                            deviceName = "未知设备";
                        }
                    }
                } catch (IllegalArgumentException e) {
                    Log.e(TAG, "无效的设备地址: " + deviceAddress);
                }
            }

            // 显示提示信息
            Toast.makeText(this, "检测到对讲数据，正在切换到对讲模式...", Toast.LENGTH_SHORT).show();

            // 切换到对讲模式
            switchToFragment("TalkbackFragment", deviceAddress, deviceName);

            // 启动重连任务
            startReconnectTask(deviceAddress, deviceName);
        });
    }

    // 启动重连任务
    private void startReconnectTask(String deviceAddress, String deviceName) {
        // 重置连接状态
        if (bluetoothService != null) {
            bluetoothService.stop();
        }

        // 创建重连任务
        Handler reconnectHandler = new Handler();
        int[] reconnectAttempts = {0}; // 记录重连次数

        Runnable reconnectRunnable = new Runnable() {
            @Override
            public void run() {
                // 检查是否已经连接
                if (bluetoothService != null && bluetoothService.getState() == BluetoothService.STATE_CONNECTED) {
                    Toast.makeText(MainActivityNew.this, "已成功连接到 " + deviceName, Toast.LENGTH_SHORT).show();
                    return;
                }

                // 检查重连次数
                if (reconnectAttempts[0] < 2) {
                    reconnectAttempts[0]++;

                    // 显示重连提示
                    String attemptText = reconnectAttempts[0] == 1 ? "第一次" : "第二次";
                    Toast.makeText(MainActivityNew.this,
                            attemptText + "尝试连接到 " + deviceName,
                            Toast.LENGTH_SHORT).show();

                    // 尝试重连
                    BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
                    if (device != null && bluetoothService != null) {
                        // 基于设备地址的角色分配算法
                        String localAddress = bluetoothAdapter.getAddress();
                        String remoteAddress = deviceAddress;
                        boolean isInitiator = localAddress.compareTo(remoteAddress) > 0;
                        bluetoothService.setConnectionRole(isInitiator, remoteAddress);
                    }

                    // 安排下一次重连
                    reconnectHandler.postDelayed(this, 1500);
                } else {
                    // 两次重连都失败
                    Toast.makeText(MainActivityNew.this,
                            "无法连接到 " + deviceName + "，请手动重试",
                            Toast.LENGTH_LONG).show();
                }
            }
        };

        // 启动第一次重连（延迟500ms确保切换完成）
        reconnectHandler.postDelayed(reconnectRunnable, 500);
    }
}