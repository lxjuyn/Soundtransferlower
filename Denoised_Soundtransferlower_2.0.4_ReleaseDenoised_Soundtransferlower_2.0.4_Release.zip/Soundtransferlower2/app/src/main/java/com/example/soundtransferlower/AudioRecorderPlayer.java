package com.example.soundtransferlower;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.util.Log;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AudioRecorderPlayer {
    private static final String TAG = "AudioRecorderPlayer";
    private static final int SAMPLE_RATE = 8000;
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int BUFFER_SIZE = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);

    // 汉语人声主要频率范围 (300Hz-3400Hz)
    private static final int VOICE_LOW_FREQ = 300;
    private static final int VOICE_HIGH_FREQ = 3400;

    // 典型汉语语音响度范围 (45-75 dB SPL)
    private static final double MIN_VOICE_DB = 45.0;
    private static final double MAX_VOICE_DB = 75.0;

    private AudioRecord audioRecord;
    private AudioTrack audioTrack;
    private volatile boolean isRecording = false;
    private volatile boolean isPlaying = false;

    // 使用单线程执行器确保顺序播放
    private final ExecutorService playbackExecutor = Executors.newSingleThreadExecutor();

    // 噪声抑制相关变量
    private short[] previousSamples = new short[160]; // 20ms的先前样本
    private double noiseFloor = 0.01; // 初始噪声底限估计
    private final double NOISE_FLOOR_ADJUSTMENT = 0.0005; // 噪声底限调整速率
    private final double VOICE_THRESHOLD = 1.5; // 语音检测阈值

    // 网络适应性变量
    private int networkCondition = 0; // 0:良好, 1:一般, 2:差
    private int consecutiveDrops = 0;
    private final int NETWORK_CHECK_INTERVAL = 10; // 每10个包检查一次网络状况

    public interface AudioDataSender {
        void sendAudioData(byte[] data);
    }

    private AudioDataSender audioDataSender;

    public AudioRecorderPlayer(Context context) {
        initAudio();
    }

    public void setAudioDataSender(AudioDataSender sender) {
        this.audioDataSender = sender;
    }

    @SuppressLint("MissingPermission")
    private void initAudio() {
        try {
            audioRecord = new AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION, // 使用语音通信源以减少回声
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    BUFFER_SIZE * 2);

            // 配置音频轨道以减少回声和啸叫
            audioTrack = new AudioTrack(
                    android.media.AudioManager.STREAM_VOICE_CALL,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AUDIO_FORMAT,
                    BUFFER_SIZE * 2,
                    AudioTrack.MODE_STREAM);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                audioTrack.setVolume(AudioTrack.getMaxVolume() * 0.7f); // 降低音量以减少啸叫
            }

            Log.d(TAG, "音频录制和播放初始化成功");
        } catch (Exception e) {
            Log.e(TAG, "音频初始化失败: " + e.getMessage());
        }
    }

    public void startRecording() {
        if (audioRecord == null || isRecording) return;

        Log.d(TAG, "开始录音");
        new Thread(() -> {
            try {
                audioRecord.startRecording();
                isRecording = true;
                Log.d(TAG, "录音已启动");

                int fixedBufferSize = 640; // 固定为640字节 (40ms)
                byte[] pcmBuffer = new byte[fixedBufferSize];
                byte[] encodedBuffer = new byte[fixedBufferSize / 2]; // μ-law编码后数据减半

                int packetCounter = 0;

                while (isRecording) {
                    int totalRead = 0;
                    // 循环读取直到填满缓冲区
                    while (totalRead < fixedBufferSize) {
                        int bytesRead = audioRecord.read(pcmBuffer, totalRead, fixedBufferSize - totalRead);
                        if (bytesRead <= 0) break;
                        totalRead += bytesRead;
                    }

                    if (totalRead > 0 && audioDataSender != null) {
                        // 只发送完整的数据包
                        if (totalRead == fixedBufferSize) {
                            // 应用噪声抑制和语音增强
                            applyNoiseSuppression(pcmBuffer, totalRead);

                            // 将PCM数据编码为μ-law
                            int encodedSize = encodeMuLaw(pcmBuffer, encodedBuffer, totalRead);

                            // 根据网络状况调整编码
                            byte[] dataToSend = adaptToNetworkConditions(encodedBuffer, encodedSize);

                            Log.d(TAG, "录制到 " + totalRead + " 字节PCM数据，编码为 " + dataToSend.length + " 字节发送数据");
                            audioDataSender.sendAudioData(dataToSend);

                            // 定期检查网络状况
                            if (++packetCounter % NETWORK_CHECK_INTERVAL == 0) {
                                evaluateNetworkConditions();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "录制错误: " + e.getMessage());
            } finally {
                stopRecordingInternal();
                Log.d(TAG, "录音线程结束");
            }
        }).start();
    }

    public void stopRecording() {
        if (isRecording) {
            isRecording = false;
        }
    }

    private void stopRecordingInternal() {
        if (audioRecord != null && audioRecord.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
            Log.d(TAG, "停止录音");
            audioRecord.stop();
            Log.d(TAG, "录音已停止");
        }
    }

    public void playAudio(byte[] encodedData, int length) {
        if (audioTrack == null || length <= 0) return;

        playbackExecutor.execute(() -> {
            try {
                if (audioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioTrack未初始化");
                    return;
                }

                if (audioTrack.getPlayState() != AudioTrack.PLAYSTATE_PLAYING) {
                    audioTrack.play();
                    isPlaying = true;
                    Log.d(TAG, "音频播放已启动");
                }

                // 解码μ-law数据为PCM
                byte[] pcmData = new byte[length * 2]; // μ-law解码后数据翻倍
                int decodedSize = decodeMuLaw(encodedData, pcmData, length);

                // 应用回声抑制和音频增强
                applyEchoSuppression(pcmData, decodedSize);

                Log.d(TAG, "接收到 " + length + " 字节μ-law数据，解码为 " + decodedSize + " 字节PCM数据");

                // 优化缓冲区大小计算
                int bufferSize = calculateOptimalBufferSize();
                Log.d(TAG, "优化后的缓冲区大小: " + bufferSize);

                int written = 0;
                while (written < decodedSize) {
                    int bytesToWrite = Math.min(bufferSize, decodedSize - written);
                    int result = audioTrack.write(pcmData, written, bytesToWrite);

                    if (result > 0) {
                        written += result;
                    } else {
                        Log.e(TAG, "AudioTrack写入错误: " + result);
                        break;
                    }
                }

                Log.d(TAG, "成功播放音频数据，长度: " + decodedSize);
            } catch (Exception e) {
                Log.e(TAG, "播放错误: " + e.getMessage());
            }
        });
    }

    /**
     * 应用噪声抑制算法
     */
    private void applyNoiseSuppression(byte[] audioData, int length) {
        // 将字节转换为short进行处理
        short[] samples = new short[length / 2];
        for (int i = 0; i < samples.length; i++) {
            samples[i] = (short) ((audioData[i * 2] & 0xFF) | (audioData[i * 2 + 1] << 8));
        }

        // 计算当前帧的能量
        double energy = calculateEnergy(samples);

        // 更新噪声底限估计
        if (energy < noiseFloor * VOICE_THRESHOLD) {
            // 可能是噪声，缓慢降低噪声底限
            noiseFloor = noiseFloor * (1 - NOISE_FLOOR_ADJUSTMENT) + energy * NOISE_FLOOR_ADJUSTMENT;
        } else {
            // 可能是语音，非常缓慢地调整噪声底限
            noiseFloor = noiseFloor * (1 - NOISE_FLOOR_ADJUSTMENT / 10) + energy * (NOISE_FLOOR_ADJUSTMENT / 10);
        }

        // 应用谱减法降噪
        spectralSubtraction(samples);

        // 应用汉语人声频率增强 (300-3400Hz)
        enhanceVoiceFrequency(samples);

        // 将处理后的short转换回字节
        for (int i = 0; i < samples.length; i++) {
            audioData[i * 2] = (byte) (samples[i] & 0xFF);
            audioData[i * 2 + 1] = (byte) ((samples[i] >> 8) & 0xFF);
        }

        // 保存当前样本用于下一帧处理
        System.arraycopy(samples, Math.max(0, samples.length - previousSamples.length),
                previousSamples, 0, Math.min(samples.length, previousSamples.length));
    }

    /**
     * 计算音频帧的能量
     */
    private double calculateEnergy(short[] samples) {
        double sum = 0;
        for (short sample : samples) {
            sum += sample * sample;
        }
        return Math.sqrt(sum / samples.length) / 32768.0;
    }

    /**
     * 简单的谱减法降噪
     */
    private void spectralSubtraction(short[] samples) {
        // 简单的时域谱减法实现
        for (int i = 0; i < samples.length; i++) {
            double amplitude = Math.abs(samples[i]) / 32768.0;
            double sign = Math.signum(samples[i]);

            // 减去噪声底限估计
            amplitude = Math.max(0, amplitude - noiseFloor);

            // 重新缩放并应用符号
            samples[i] = (short) (sign * amplitude * 32767.0);
        }
    }

    /**
     * 增强汉语人声主要频率范围
     */
    private void enhanceVoiceFrequency(short[] samples) {
        // 简单的预加重滤波器，增强高频成分
        double alpha = 0.95;
        for (int i = 1; i < samples.length; i++) {
            samples[i] = (short) (samples[i] - alpha * samples[i-1]);
        }
    }

    /**
     * 应用回声抑制
     */
    private void applyEchoSuppression(byte[] audioData, int length) {
        // 简单的回声抑制：降低突然的高音量部分
        short[] samples = new short[length / 2];
        for (int i = 0; i < samples.length; i++) {
            samples[i] = (short) ((audioData[i * 2] & 0xFF) | (audioData[i * 2 + 1] << 8));
        }

        // 简单的动态范围压缩，减少啸叫
        for (int i = 0; i < samples.length; i++) {
            double amplitude = Math.abs(samples[i]) / 32768.0;
            double sign = Math.signum(samples[i]);

            // 压缩高振幅部分
            if (amplitude > 0.6) { // 超过60%的幅度
                amplitude = 0.6 + (amplitude - 0.6) * 0.5; // 压缩因子0.5
            }

            samples[i] = (short) (sign * amplitude * 32767.0);
        }

        // 转换回字节
        for (int i = 0; i < samples.length; i++) {
            audioData[i * 2] = (byte) (samples[i] & 0xFF);
            audioData[i * 2 + 1] = (byte) ((samples[i] >> 8) & 0xFF);
        }
    }

    /**
     * 根据网络状况调整编码和数据
     */
    private byte[] adaptToNetworkConditions(byte[] encodedData, int length) {
        switch (networkCondition) {
            case 0: // 良好网络
                return encodedData; // 返回完整数据

            case 1: // 一般网络
                // 降低比特率，减少数据量
                return reduceBitrate(encodedData, length);

            case 2: // 差网络
                // 进一步减少数据量，增加冗余
                return addRedundancy(encodedData, length);

            default:
                return encodedData;
        }
    }

    /**
     * 降低比特率以减少数据量
     */
    private byte[] reduceBitrate(byte[] data, int length) {
        // 简单的降低比特率方法：每两个样本取一个
        if (length <= 2) return data;

        int newLength = (length + 1) / 2;
        byte[] reducedData = new byte[newLength];

        for (int i = 0; i < newLength; i++) {
            reducedData[i] = data[i * 2];
        }

        return reducedData;
    }

    /**
     * 添加前向纠错冗余以提高抗丢包能力
     */
    private byte[] addRedundancy(byte[] data, int length) {
        // 简单的重复编码增加冗余
        byte[] redundantData = new byte[length * 2];

        for (int i = 0; i < length; i++) {
            redundantData[i] = data[i];
            redundantData[i + length] = data[i]; // 重复数据
        }

        return redundantData;
    }

    /**
     * 评估网络状况
     */
    private void evaluateNetworkConditions() {
        // 这里应该是从网络层获取实际的网络状况
        // 暂时使用模拟实现

        if (consecutiveDrops > 3) {
            networkCondition = 2; // 网络差
        } else if (consecutiveDrops > 1) {
            networkCondition = 1; // 网络一般
        } else {
            networkCondition = 0; // 网络良好
        }

        Log.d(TAG, "网络状况评估: " + networkCondition);
    }

    /**
     * 计算优化的缓冲区大小
     */
    private int calculateOptimalBufferSize() {
        int bufferSize;

        // 优先使用AudioTrack的推荐缓冲区大小
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Android 6.0+ 使用 getBufferSizeInFrames()
            bufferSize = audioTrack.getBufferSizeInFrames() * 2; // 每帧2字节（16位）
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // Android 5.0+ 使用 getBufferSizeInBytes()
            try {
                bufferSize = (Integer) AudioTrack.class.getMethod("getBufferSizeInBytes").invoke(audioTrack);
            } catch (Exception e) {
                // 回退到固定大小
                bufferSize = BUFFER_SIZE * 2;
            }
        } else {
            // Android 4.4 及以下版本使用固定缓冲区大小
            // 使用更小的缓冲区以减少延迟
            bufferSize = Math.max(1024, BUFFER_SIZE / 2);
        }

        // 根据网络状况调整缓冲区大小
        switch (networkCondition) {
            case 0: // 良好网络
                bufferSize = Math.max(512, Math.min(bufferSize, 4096));
                break;
            case 1: // 一般网络
                bufferSize = Math.max(1024, Math.min(bufferSize, 6144));
                break;
            case 2: // 差网络
                bufferSize = Math.max(2048, Math.min(bufferSize, 8192));
                break;
        }

        return bufferSize;
    }

    public void release() {
        stopRecording();
        isPlaying = false;

        playbackExecutor.shutdownNow();

        if (audioRecord != null) {
            stopRecordingInternal();
            audioRecord.release();
            audioRecord = null;
        }

        if (audioTrack != null) {
            if (audioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) {
                audioTrack.stop();
            }
            audioTrack.release();
            audioTrack = null;
        }

        Log.d(TAG, "音频资源已释放");
    }

    /**
     * μ-law编码表
     */
    private static final short[] MU_LAW_TABLE = {
            -32124, -31100, -30076, -29052, -28028, -27004, -25980, -24956,
            -23932, -22908, -21884, -20860, -19836, -18812, -17788, -16764,
            -15996, -15484, -14972, -14460, -13948, -13436, -12924, -12412,
            -11900, -11388, -10876, -10364, -9852, -9340, -8828, -8316,
            -7932, -7676, -7420, -7164, -6908, -6652, -6396, -6140,
            -5884, -5628, -5372, -5116, -4860, -4604, -4348, -4092,
            -3900, -3772, -3644, -3516, -3388, -3260, -3132, -3004,
            -2876, -2748, -2620, -2492, -2364, -2236, -2108, -1980,
            -1884, -1820, -1756, -1692, -1628, -1564, -1500, -1436,
            -1372, -1308, -1244, -1180, -1116, -1052, -988, -924,
            -876, -844, -812, -780, -748, -716, -684, -652,
            -620, -588, -556, -524, -492, -460, -428, -396,
            -372, -356, -340, -324, -308, -292, -276, -260,
            -244, -228, -212, -196, -180, -164, -148, -132,
            -120, -112, -104, -96, -88, -80, -72, -64,
            -56, -48, -40, -32, -24, -16, -8, 0,
            32124, 31100, 30076, 29052, 28028, 27004, 25980, 24956,
            23932, 22908, 21884, 20860, 19836, 18812, 17788, 16764,
            15996, 15484, 14972, 14460, 13948, 13436, 12924, 12412,
            11900, 11388, 10876, 10364, 9852, 9340, 8828, 8316,
            7932, 7676, 7420, 7164, 6908, 6652, 6396, 6140,
            5884, 5628, 5372, 5116, 4860, 4604, 4348, 4092,
            3900, 3772, 3644, 3516, 3388, 3260, 3132, 3004,
            2876, 2748, 2620, -2492, -2364, -2236, -2108, -1980,
            -1884, -1820, -1756, -1692, -1628, -1564, -1500, -1436,
            -1372, -1308, -1244, -1180, -1116, -1052, -988, -924,
            -876, -844, -812, -780, -748, -716, -684, -652,
            -620, -588, -556, -524, -492, -460, -428, -396,
            -372, -356, -340, -324, -308, -292, -276, -260,
            -244, -228, -212, -196, -180, -164, -148, -132,
            -120, -112, -104, -96, -88, -80, -72, -64,
            -56, -48, -40, -32, -24, -16, -8, 0
    };

    /**
     * 将PCM数据编码为μ-law格式
     * @param pcmData PCM输入数据
     * @param encodedData 编码后的输出数据
     * @param pcmLength PCM数据长度
     * @return 编码后的数据长度
     */
    private int encodeMuLaw(byte[] pcmData, byte[] encodedData, int pcmLength) {
        // 确保输入数据是偶数长度（16位样本）
        int sampleCount = pcmLength / 2;

        for (int i = 0; i < sampleCount; i++) {
            // 将两个字节组合成16位有符号整数（小端序）
            short sample = (short) ((pcmData[i * 2] & 0xFF) | (pcmData[i * 2 + 1] << 8));

            // 查找最接近的μ-law值
            int sign = (sample & 0x8000) >> 8;
            if (sign != 0) {
                sample = (short) -sample;
            }

            if (sample > 32767) sample = 32767;

            int exponent = 7;
            int mask = 0x4000;

            // 找到最高有效位的位置
            while ((sample & mask) == 0 && exponent > 0) {
                exponent--;
                mask >>= 1;
            }

            int mantissa = (sample >> (exponent + 3)) & 0x0F;
            byte encoded = (byte) (sign | (exponent << 4) | mantissa);

            // 取反并存储
            encodedData[i] = (byte) ~encoded;
        }

        return sampleCount;
    }

    /**
     * 将μ-law数据解码为PCM格式
     * @param encodedData μ-law输入数据
     * @param pcmData PCM输出数据
     * @param encodedLength 编码数据长度
     * @return 解码后的PCM数据长度
     */
    private int decodeMuLaw(byte[] encodedData, byte[] pcmData, int encodedLength) {
        for (int i = 0; i < encodedLength; i++) {
            // 取反获取原始编码值
            byte ulaw = (byte) ~encodedData[i];

            // 提取符号、指数和尾数
            int sign = (ulaw & 0x80) >> 7;
            int exponent = (ulaw & 0x70) >> 4;
            int mantissa = ulaw & 0x0F;

            // 重建线性样本
            int sample = (mantissa << 3) + 0x84;
            sample <<= exponent;
            sample -= 0x84;

            if (sign == 0) {
                sample = -sample;
            }

            // 限制到16位范围
            if (sample > 32767) sample = 32767;
            if (sample < -32768) sample = -32768;

            // 拆分为两个字节（小端序）
            pcmData[i * 2] = (byte) (sample & 0xFF);
            pcmData[i * 2 + 1] = (byte) ((sample >> 8) & 0xFF);
        }

        return encodedLength * 2;
    }

    // 新增方法：设置网络状况（应由网络层调用）
    public void setNetworkCondition(int condition) {
        this.networkCondition = condition;
        if (condition == 2) {
            consecutiveDrops++;
        } else {
            consecutiveDrops = 0;
        }
    }

    // 新增方法：获取当前网络状况
    public int getNetworkCondition() {
        return networkCondition;
    }
}