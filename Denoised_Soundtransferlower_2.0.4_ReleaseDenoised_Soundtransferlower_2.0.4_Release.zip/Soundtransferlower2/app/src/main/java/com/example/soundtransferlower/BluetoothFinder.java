package com.example.soundtransferlower;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import java.util.ArrayList;
import java.util.Set;

public class BluetoothFinder {
    private final Context context;
    private final BluetoothAdapter bluetoothAdapter;
    private final ArrayList<BluetoothDevice> scannedDevices = new ArrayList<>();
    private final ArrayList<BluetoothDevice> pairedDevices = new ArrayList<>();
    private final ArrayList<BluetoothDevice> duplicateDevices = new ArrayList<>();
    private final BroadcastReceiver scanReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null && !scannedDevices.contains(device)) {
                    scannedDevices.add(device);
                    checkForDuplicates(device); // 实时更新重复设备
                }
            }
        }
    };

    public BluetoothFinder(Context context) {
        this.context = context;
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    // 开始扫描蓝牙设备
    public void startScan() {
        scannedDevices.clear();
        duplicateDevices.clear();

        // 注册扫描广播接收器
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        context.registerReceiver(scanReceiver, filter);

        if (bluetoothAdapter != null) {
            bluetoothAdapter.startDiscovery();
        }
    }

    // 停止扫描
    public void stopScan() {
        if (bluetoothAdapter != null && bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
        context.unregisterReceiver(scanReceiver);
    }

    // 获取已配对设备列表
    public void fetchPairedDevices() {
        pairedDevices.clear();
        if (bluetoothAdapter != null) {
            Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
            pairedDevices.addAll(bondedDevices);
        }
        updateDuplicates(); // 更新重复设备列表
    }

    // 检查单个设备是否重复
    private void checkForDuplicates(BluetoothDevice device) {
        if (pairedDevices.contains(device) && !duplicateDevices.contains(device)) {
            duplicateDevices.add(device);
        }
    }

    // 更新整个重复设备列表
    private void updateDuplicates() {
        duplicateDevices.clear();
        for (BluetoothDevice device : scannedDevices) {
            if (pairedDevices.contains(device)) {
                duplicateDevices.add(device);
            }
        }
    }

    // 获取扫描到的设备列表
    public ArrayList<BluetoothDevice> getScannedDevices() {
        return new ArrayList<>(scannedDevices);
    }

    // 获取已配对设备列表
    public ArrayList<BluetoothDevice> getPairedDevices() {
        return new ArrayList<>(pairedDevices);
    }

    // 获取重复设备列表
    public ArrayList<BluetoothDevice> getDuplicateDevices() {
        return new ArrayList<>(duplicateDevices);
    }
}