package com.example.soundtransferlower;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class BluetoothService extends Service {
    private static final String TAG = "BluetoothService";
    private static final String APP_NAME = "SoundTransfer";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    // 文本消息前缀
    public static final String TEXT_PREFIX = "TXT:";
    public static final byte[] TEXT_PREFIX_BYTES = TEXT_PREFIX.getBytes();
    private final IBinder binder = new LocalBinder();
    private BluetoothAdapter bluetoothAdapter;
    private AcceptThread acceptThread;
    private ConnectThread connectThread;
    private ConnectedThread connectedThread;
    private int state;
    private String connectedDeviceAddress;

    // 连接角色管理
    private boolean isInitiator = false;
    private String targetDeviceAddress = null;

    // 状态常量
    public static final int STATE_NONE = 0;
    public static final int STATE_LISTEN = 1;
    public static final int STATE_CONNECTING = 2;
    public static final int STATE_CONNECTED = 3;

    // 模式常量：文本聊天模式或对讲模式
    public static final int MODE_CHAT = 0;
    public static final int MODE_TALKBACK = 1;
    private int currentMode = MODE_CHAT; // 默认是文本聊天模式

    // 回调接口列表，支持多个回调
    private List<MessageCallback> messageCallbacks = new ArrayList<>();

    public interface MessageCallback {
        void onMessageReceived(String message, String deviceAddress);
        void onConnectionStatusChanged(int state, String deviceName);
        // 新增对讲数据回调
        void onTalkbackDataReceived(byte[] data, String deviceAddress);
        // 新增方法：当在聊天模式下收到非文本数据时调用
        void onNonTextDataReceived(String deviceAddress);
    }

    public class LocalBinder extends Binder {
        public BluetoothService getService() {
            return BluetoothService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        state = STATE_NONE;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 服务被杀死后自动重启
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stop();
    }

    // 设置连接角色
    public void setConnectionRole(boolean isInitiator, String targetDeviceAddress) {
        this.isInitiator = isInitiator;
        this.targetDeviceAddress = targetDeviceAddress;

        if (isInitiator && targetDeviceAddress != null) {
            // 作为发起方，停止监听并尝试连接
            stop();
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(targetDeviceAddress);
            connect(device);
        } else {
            // 作为接收方，启动监听
            start();
        }
    }

    // 设置模式：文本聊天或对讲
    public void setMode(int mode) {
        currentMode = mode;
    }

    public int getMode() {
        return currentMode;
    }

    // 注册回调
    public void registerCallback(MessageCallback callback) {
        if (!messageCallbacks.contains(callback)) {
            messageCallbacks.add(callback);
        }
    }

    // 注销回调
    public void unregisterCallback(MessageCallback callback) {
        messageCallbacks.remove(callback);
    }

    // 通知所有回调消息接收
    private void notifyMessageReceived(String message, String deviceAddress) {
        new Handler(Looper.getMainLooper()).post(() -> {
            for (MessageCallback callback : messageCallbacks) {
                callback.onMessageReceived(message, deviceAddress);
            }
        });
    }

    // 通知所有回调连接状态变化
    private void notifyConnectionStatusChanged(int state, String deviceName) {
        new Handler(Looper.getMainLooper()).post(() -> {
            for (MessageCallback callback : messageCallbacks) {
                callback.onConnectionStatusChanged(state, deviceName);
            }
        });
    }

    // 通知对讲数据接收
    private void notifyTalkbackDataReceived(byte[] data, String deviceAddress) {
        new Handler(Looper.getMainLooper()).post(() -> {
            for (MessageCallback callback : messageCallbacks) {
                callback.onTalkbackDataReceived(data, deviceAddress);
            }
        });
    }

    // 新增方法：通知非文本数据接收
    private void notifyNonTextDataReceived(String deviceAddress) {
        new Handler(Looper.getMainLooper()).post(() -> {
            for (MessageCallback callback : messageCallbacks) {
                callback.onNonTextDataReceived(deviceAddress);
            }
        });
    }

    public synchronized void start() {
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }

        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }

        if (acceptThread == null) {
            acceptThread = new AcceptThread();
            acceptThread.start();
        }
        setState(STATE_LISTEN);
    }

    public synchronized void connect(BluetoothDevice device) {
        if (state == STATE_CONNECTING) {
            if (connectThread != null) {
                connectThread.cancel();
                connectThread = null;
            }
        }

        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }

        connectThread = new ConnectThread(device);
        connectThread.start();
        setState(STATE_CONNECTING);
    }

    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }

        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }

        if (acceptThread != null) {
            acceptThread.cancel();
            acceptThread = null;
        }

        connectedThread = new ConnectedThread(socket);
        connectedThread.start();

        connectedDeviceAddress = device.getAddress();

        // 重置连接角色
        isInitiator = false;
        targetDeviceAddress = null;

        notifyConnectionStatusChanged(STATE_CONNECTED, device.getName());
        setState(STATE_CONNECTED);
    }

    public synchronized void stop() {
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }

        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }

        if (acceptThread != null) {
            acceptThread.cancel();
            acceptThread = null;
        }

        setState(STATE_NONE);
    }

    public void write(byte[] out) {
        write(out, currentMode);
    }

    public void write(byte[] out, int mode) {
        ConnectedThread r;
        synchronized (this) {
            if (state != STATE_CONNECTED) return;
            r = connectedThread;
        }
        r.write(out, mode);
    }

    private void setState(int newState) {
        state = newState;
    }

    public int getState() {
        return state;
    }

    public String getConnectedDeviceAddress() {
        return connectedDeviceAddress;
    }

    private void connectionFailed() {
        notifyConnectionStatusChanged(STATE_LISTEN, "连接失败");

        // 如果是发起方且连接失败，尝试回退到监听模式
        if (isInitiator) {
            isInitiator = false;
            targetDeviceAddress = null;
        }

        setState(STATE_LISTEN);
        BluetoothService.this.start();
    }

    private void connectionLost() {
        notifyConnectionStatusChanged(STATE_LISTEN, "连接断开");

        // 重置连接角色
        isInitiator = false;
        targetDeviceAddress = null;

        setState(STATE_LISTEN);
        BluetoothService.this.start();
    }

    private class AcceptThread extends Thread {
        private final BluetoothServerSocket serverSocket;

        public AcceptThread() {
            BluetoothServerSocket tmp = null;
            try {
                tmp = bluetoothAdapter.listenUsingRfcommWithServiceRecord(APP_NAME, MY_UUID);
            } catch (IOException e) {
                Log.e(TAG, "Socket listen() failed", e);
            }
            serverSocket = tmp;
        }

        public void run() {
            setName("AcceptThread");
            BluetoothSocket socket;

            while (state != STATE_CONNECTED) {
                try {
                    socket = serverSocket.accept();
                } catch (IOException e) {
                    Log.e(TAG, "Socket accept() failed", e);
                    break;
                }

                if (socket != null) {
                    synchronized (BluetoothService.this) {
                        switch (state) {
                            case STATE_LISTEN:
                            case STATE_CONNECTING:
                                connected(socket, socket.getRemoteDevice());
                                break;
                            case STATE_NONE:
                            case STATE_CONNECTED:
                                try {
                                    socket.close();
                                } catch (IOException e) {
                                    Log.e(TAG, "Could not close unwanted socket", e);
                                }
                                break;
                        }
                    }
                }
            }
        }

        public void cancel() {
            try {
                serverSocket.close();
            } catch (IOException e) {
                Log.e(TAG, "Socket close() of server failed", e);
            }
        }
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket socket;
        private final BluetoothDevice device;

        public ConnectThread(BluetoothDevice device) {
            this.device = device;
            BluetoothSocket tmp = null;

            try {
                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
                Log.e(TAG, "Socket create() failed", e);
            }
            socket = tmp;
        }

        public void run() {
            setName("ConnectThread");
            bluetoothAdapter.cancelDiscovery();

            try {
                socket.connect();
            } catch (IOException e) {
                connectionFailed();
                try {
                    socket.close();
                } catch (IOException e2) {
                    Log.e(TAG, "unable to close() socket during connection failure", e2);
                }
                return;
            }

            synchronized (BluetoothService.this) {
                connectThread = null;
            }

            connected(socket, device);
        }

        public void cancel() {
            try {
                socket.close();
            } catch (IOException e) {
                Log.e(TAG, "close() of connect socket failed", e);
            }
        }
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket socket;
        private final InputStream inputStream;
        private final OutputStream outputStream;
        private boolean isRunning = true;

        public ConnectedThread(BluetoothSocket socket) {
            this.socket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "temp sockets not created", e);
            }

            inputStream = tmpIn;
            outputStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;

            while (isRunning) {
                try {
                    bytes = inputStream.read(buffer);
                    if (bytes > 0) {
                        // 检查是否是文本消息（以TXT:开头）
                        if (isTextMessage(buffer, bytes)) {
                            // 处理文本消息
                            String message = new String(buffer, TEXT_PREFIX_BYTES.length, bytes - TEXT_PREFIX_BYTES.length);
                            saveMessageToFile(message, socket.getRemoteDevice().getAddress());
                            notifyMessageReceived(message, socket.getRemoteDevice().getAddress());
                        } else {
                            // 处理音频数据
                            if (currentMode == MODE_TALKBACK) {
                                byte[] audioData = new byte[bytes];
                                System.arraycopy(buffer, 0, audioData, 0, bytes);
                                notifyTalkbackDataReceived(audioData, socket.getRemoteDevice().getAddress());
                            } else {
                                // 聊天模式下的非文本数据（不应该发生）
                                Log.w(TAG, "Received non-text data in chat mode");
                                // 新增：通知非文本数据接收
                                notifyNonTextDataReceived(socket.getRemoteDevice().getAddress());
                            }
                        }
                    }
                } catch (IOException e) {
                    connectionLost();
                    break;
                }
            }
        }

        // 检查是否是文本消息
        private boolean isTextMessage(byte[] data, int length) {
            if (length < TEXT_PREFIX_BYTES.length) {
                return false;
            }

            for (int i = 0; i < TEXT_PREFIX_BYTES.length; i++) {
                if (data[i] != TEXT_PREFIX_BYTES[i]) {
                    return false;
                }
            }

            return true;
        }

        public void write(byte[] buffer) {
            write(buffer, currentMode);
        }

        public void write(byte[] buffer, int mode) {
            try {
                outputStream.write(buffer);
                outputStream.flush();

                if (mode == MODE_CHAT) {
                    // 文本模式，保存自己发送的消息
                    String message = new String(buffer);
                    // 修复bug: 检查消息是否以TXT:开头，如果是则移除前缀
                    if (message.startsWith(TEXT_PREFIX)) {
                        message = message.substring(TEXT_PREFIX.length());
                    }
                    saveMessageToFile("我: " + message, socket.getRemoteDevice().getAddress());
                    // 不再通知自己发送的消息，避免重复
                }
                // 对讲模式不保存消息
            } catch (IOException e) {
                Log.e(TAG, "Exception during write", e);
            }
        }

        public void cancel() {
            isRunning = false;
            try {
                socket.close();
            } catch (IOException e) {
                Log.e(TAG, "close() of connect socket failed", e);
            }
        }
    }

    private void saveMessageToFile(String message, String deviceAddress) {
        try {
            // 使用设备地址作为文件名，但替换冒号
            String filename = "chat_" + deviceAddress.replace(":", "_") + ".txt";
            File file = new File(getExternalFilesDir(null), filename);

            // 如果文件不存在则创建
            if (!file.exists()) {
                file.createNewFile();
            }

            // 添加时间戳
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String timestamp = sdf.format(new Date());

            // 追加消息到文件
            FileOutputStream fos = new FileOutputStream(file, true);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
            osw.write(timestamp + ": " + message + "\n");
            osw.close();

        } catch (IOException e) {
            Log.e(TAG, "Error saving message to file", e);
        }
    }

    public String loadChatHistory(String deviceAddress) {
        StringBuilder chatHistory = new StringBuilder();
        try {
            String filename = "chat_" + deviceAddress.replace(":", "_") + ".txt";
            File file = new File(getExternalFilesDir(null), filename);

            if (file.exists()) {
                InputStream inputStream = getContentResolver().openInputStream(android.net.Uri.fromFile(file));
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    chatHistory.append(line).append("\n");
                }

                reader.close();
            }
        } catch (IOException e) {
            Log.e(TAG, "Error loading chat history", e);
        }
        return chatHistory.toString();
    }
}