package com.example.soundtransferlower;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatWorkFragment extends Fragment implements BluetoothService.MessageCallback {
    private static final String TAG = "ChatWorkFragment";

    private TextView tvDeviceName;
    private RecyclerView recyclerViewMessages;
    private EditText etMessage;
    private Button btnSend;
    private Button btnMore;

    private BluetoothService bluetoothService;
    private boolean serviceBound = false;
    private String deviceAddress;
    private String deviceName;

    private MessageAdapter messageAdapter;
    private List<Message> messageList = new ArrayList<>();

    // 用于删除确认的状态变量
    private boolean deleteConfirmation = false;
    private Handler deleteHandler = new Handler();
    private Runnable deleteResetRunnable = new Runnable() {
        @Override
        public void run() {
            deleteConfirmation = false;
            Toast.makeText(getActivity(), "删除操作已取消", Toast.LENGTH_SHORT).show();
        }
    };

    // 新增：用于检测非文本数据包
    private int nonTextDataCount = 0;
    private Handler nonTextHandler = new Handler(Looper.getMainLooper());
    private Runnable resetNonTextDataCount = new Runnable() {
        @Override
        public void run() {
            nonTextDataCount = 0;
        }
    };

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BluetoothService.LocalBinder binder = (BluetoothService.LocalBinder) service;
            bluetoothService = binder.getService();
            bluetoothService.registerCallback(ChatWorkFragment.this);
            serviceBound = true;

            // 设置聊天模式
            bluetoothService.setMode(BluetoothService.MODE_CHAT);

            // 如果是从设备列表点击进入，尝试连接设备
            if (deviceAddress != null) {
                BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
                bluetoothService.connect(device);

                // 加载聊天记录
                loadChatHistory();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_chat, container, false);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        // 获取传递过来的设备信息
        Bundle args = getArguments();
        if (args != null) {
            deviceAddress = args.getString("DEVICE_ADDRESS");
            deviceName = args.getString("DEVICE_NAME");
        }

        // 初始化UI
        initUI(view);

        // 绑定蓝牙服务
        Intent serviceIntent = new Intent(getActivity(), BluetoothService.class);
        getActivity().bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        return view;
    }

    private void initUI(View view) {
        ImageButton btnBack = view.findViewById(R.id.btnBack);
        tvDeviceName = view.findViewById(R.id.tvDeviceName);
        ImageButton btnMenu = view.findViewById(R.id.btnMenu);
        recyclerViewMessages = view.findViewById(R.id.recyclerViewMessages);
        etMessage = view.findViewById(R.id.etMessage);
        btnSend = view.findViewById(R.id.btnSend);
        btnMore = view.findViewById(R.id.btnMore);

        // 设置设备名称
        if (deviceName != null) {
            tvDeviceName.setText(deviceName);
        } else {
            tvDeviceName.setText("未知设备");
        }

        // 返回按钮点击事件 - 返回到设备列表
        btnBack.setOnClickListener(v -> {
            if (getActivity() != null) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        // 菜单按钮点击事件
        btnMenu.setOnClickListener(v -> showMenuOptions());

        // 发送按钮点击事件
        btnSend.setOnClickListener(v -> sendMessage());

        // 更多按钮点击事件
        btnMore.setOnClickListener(v -> showMoreOptions());

        // 设置消息列表
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerViewMessages.setLayoutManager(layoutManager);
        messageAdapter = new MessageAdapter(messageList);
        recyclerViewMessages.setAdapter(messageAdapter);
    }

    private void sendMessage() {
        String message = etMessage.getText().toString().trim();
        if (!TextUtils.isEmpty(message) && serviceBound) {
            // 发送带前缀的文本消息
            String prefixedMessage = BluetoothService.TEXT_PREFIX + message;
            bluetoothService.write(prefixedMessage.getBytes());

            // 清空输入框
            etMessage.setText("");

            // 本地显示消息 - 直接添加到列表
            messageList.add(new Message(message, true, new Date()));
            messageAdapter.notifyItemInserted(messageList.size() - 1);
            recyclerViewMessages.scrollToPosition(messageList.size() - 1);
        }
    }

    private void showMenuOptions() {
        PopupMenu popupMenu = new PopupMenu(getActivity(), getView().findViewById(R.id.btnMenu));
        popupMenu.getMenuInflater().inflate(R.menu.chat_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.menu_delete_chat) {
                handleDeleteChat();
                return true;
            } else if (item.getItemId() == R.id.menu_export_chat) {
                exportChatHistory();
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

    private void handleDeleteChat() {
        if (deleteConfirmation) {
            // 第二次点击 - 执行删除
            deleteHandler.removeCallbacks(deleteResetRunnable);
            deleteChatHistory();
            Toast.makeText(getActivity(), "聊天记录已删除", Toast.LENGTH_SHORT).show();
            deleteConfirmation = false;
        } else {
            // 第一次点击 - 显示警告
            Toast.makeText(getActivity(), "再次点击将删除所有聊天记录 (8秒内有效)", Toast.LENGTH_SHORT).show();
            deleteConfirmation = true;

            // 8秒后重置确认状态
            deleteHandler.postDelayed(deleteResetRunnable, 8000);
        }
    }

    private void deleteChatHistory() {
        if (deviceAddress != null && getActivity() != null) {
            // 构造文件名
            String filename = "chat_" + deviceAddress.replace(":", "_") + ".txt";
            File file = new File(getActivity().getExternalFilesDir(null), filename);

            // 删除文件
            if (file.exists()) {
                if (file.delete()) {
                    // 清空当前消息列表
                    messageList.clear();
                    messageAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(getActivity(), "删除失败", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void exportChatHistory() {
        if (messageList.isEmpty()) {
            Toast.makeText(getActivity(), "没有聊天记录可导出", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // 创建导出目录
            File exportDir = new File(Environment.getExternalStorageDirectory(), "SoundTransferExports");
            if (!exportDir.exists()) {
                if (!exportDir.mkdirs()) {
                    Toast.makeText(getActivity(), "创建导出目录失败", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            // 创建文件名（使用设备名称和时间戳）
            String safeDeviceName = deviceName != null ? deviceName.replaceAll("[^a-zA-Z0-9.-]", "_") : "unknown";
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
            String timestamp = sdf.format(new Date());
            String filename = "chat_" + safeDeviceName + "_" + timestamp + ".txt";

            File exportFile = new File(exportDir, filename);

            // 写入聊天记录
            FileOutputStream fos = new FileOutputStream(exportFile);
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");

            // 写入文件头
            osw.write("聊天记录导出 - " + (deviceName != null ? deviceName : "未知设备") + "\n");
            osw.write("导出时间: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()) + "\n\n");

            // 写入每条消息
            for (Message message : messageList) {
                String sender = message.isSent() ? "我方" : "对方";
                String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(message.getTimestamp());
                osw.write(time + " [" + sender + "]: " + message.getContent() + "\n");
            }

            osw.close();
            fos.close();

            Toast.makeText(getActivity(), "聊天记录已导出到: " + exportFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Log.e(TAG, "导出聊天记录失败", e);
            Toast.makeText(getActivity(), "导出失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void showMoreOptions() {
        PopupMenu popupMenu = new PopupMenu(getActivity(), getView().findViewById(R.id.btnMore));
        popupMenu.getMenuInflater().inflate(R.menu.chat_more_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.menu_talkback) {
                startTalkbackActivity();
                return true;
            }
            return false;
        });

        popupMenu.show();
    }

    private void startTalkbackActivity() {
        Intent intent = new Intent(getActivity(), MainActivityNew.class);
        intent.putExtra("DEVICE_ADDRESS", deviceAddress);
        intent.putExtra("DEVICE_NAME", deviceName);
        intent.putExtra("LOAD_FRAGMENT", "TalkbackFragment");
        startActivity(intent);
    }

    private void loadChatHistory() {
        if (serviceBound && deviceAddress != null) {
            String history = bluetoothService.loadChatHistory(deviceAddress);
            if (!TextUtils.isEmpty(history)) {
                // 解析聊天记录并添加到消息列表
                String[] lines = history.split("\n");
                for (String line : lines) {
                    if (line.contains(": ")) {
                        try {
                            int timeEndIndex = line.indexOf(": ");
                            String timePart = line.substring(0, timeEndIndex);
                            String messagePart = line.substring(timeEndIndex + 2);

                            boolean isSent = messagePart.startsWith("我: ");
                            String content = isSent ? messagePart.substring(3) : messagePart;

                            // 解析时间戳
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                            Date timestamp = sdf.parse(timePart);

                            messageList.add(new Message(content, isSent, timestamp));
                        } catch (Exception e) {
                            Log.e(TAG, "解析聊天记录失败: " + line, e);
                            // 如果解析失败，使用当前时间
                            boolean isSent = line.contains("我: ");
                            String content = isSent ? line.replace("我: ", "") : line;
                            messageList.add(new Message(content, isSent, new Date()));
                        }
                    }
                }
                messageAdapter.notifyDataSetChanged();
                recyclerViewMessages.scrollToPosition(messageList.size() - 1);
            }
        }
    }

    @Override
    public void onMessageReceived(String message, String deviceAddress) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                // 如果消息来自当前聊天设备，则显示
                if (this.deviceAddress != null && this.deviceAddress.equals(deviceAddress)) {
                    // 收到的消息都是对方发送的
                    messageList.add(new Message(message, false, new Date()));
                    messageAdapter.notifyItemInserted(messageList.size() - 1);
                    recyclerViewMessages.scrollToPosition(messageList.size() - 1);
                }
            });
        }
    }

    @Override
    public void onConnectionStatusChanged(int state, String deviceName) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                switch (state) {
                    case BluetoothService.STATE_CONNECTED:
                        tvDeviceName.setText(deviceName + " (已连接)");
                        break;
                    case BluetoothService.STATE_CONNECTING:
                        tvDeviceName.setText(deviceName + " (连接中...)");
                        break;
                    case BluetoothService.STATE_LISTEN:
                        tvDeviceName.setText("等待连接...");
                        break;
                }
            });
        }
    }

    // 新增：实现 onNonTextDataReceived 方法
    @Override
    public void onNonTextDataReceived(String deviceAddress) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                // 如果数据来自当前聊天设备，则处理
                if (this.deviceAddress != null && this.deviceAddress.equals(deviceAddress)) {
                    nonTextDataCount++;
                    nonTextHandler.removeCallbacks(resetNonTextDataCount);
                    // 如果连续收到两个非文本数据包，则切换
                    if (nonTextDataCount >= 2) {
                        switchToTalkbackFragment();
                    } else {
                        // 设置1秒后重置计数
                        nonTextHandler.postDelayed(resetNonTextDataCount, 1000);
                    }
                }
            });
        }
    }

    // 新增：切换到对讲Fragment
    private void switchToTalkbackFragment() {
        Toast.makeText(getActivity(), "检测到对讲连接，正在切换...", Toast.LENGTH_SHORT).show();
        if (getActivity() instanceof MainActivityNew) {
            ((MainActivityNew) getActivity()).switchToFragment("TalkbackFragment", deviceAddress, deviceName);
        }
    }

    // 添加对讲数据接收方法（空实现，因为聊天Fragment不需要处理对讲数据）
    @Override
    public void onTalkbackDataReceived(byte[] data, String deviceAddress) {
        // 聊天Fragment不处理对讲数据，所以空实现
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // 移除所有回调
        deleteHandler.removeCallbacks(deleteResetRunnable);
        nonTextHandler.removeCallbacks(resetNonTextDataCount);

        if (serviceBound && getActivity() != null) {
            bluetoothService.unregisterCallback(this);
            getActivity().unbindService(serviceConnection);
            serviceBound = false;
        }
    }

    // 修改Message类以包含时间戳
    public static class Message {
        private String content;
        private boolean isSent;
        private Date timestamp;

        public Message(String content, boolean isSent, Date timestamp) {
            this.content = content;
            this.isSent = isSent;
            this.timestamp = timestamp;
        }

        public String getContent() {
            return content;
        }

        public boolean isSent() {
            return isSent;
        }

        public Date getTimestamp() {
            return timestamp;
        }
    }
}