package com.example.soundtransferlower;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.util.Log;
import java.nio.ByteBuffer;

public class AudioCodec {
    private static final String TAG = "AudioCodec";
    private static final String MIME_TYPE = "audio/amr-wb"; // AMR-WB 格式
    private static final int SAMPLE_RATE = 8000;
    private static final int BIT_RATE = 12200; // 12.2 kbps

    private MediaCodec encoder;
    private MediaCodec decoder;
    private boolean isInitialized = false;

    public void init() {
        try {
            // 初始化编码器
            encoder = MediaCodec.createEncoderByType(MIME_TYPE);
            MediaFormat encodeFormat = MediaFormat.createAudioFormat(MIME_TYPE, SAMPLE_RATE, 1);
            encodeFormat.setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE);
            encoder.configure(encodeFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();

            // 初始化解码器
            decoder = MediaCodec.createDecoderByType(MIME_TYPE);
            MediaFormat decodeFormat = MediaFormat.createAudioFormat(MIME_TYPE, SAMPLE_RATE, 1);
            decoder.configure(decodeFormat, null, null, 0);
            decoder.start();

            isInitialized = true;
            Log.d(TAG, "音频编解码器初始化成功");
        } catch (Exception e) {
            Log.e(TAG, "音频编解码器初始化失败: " + e.getMessage());
        }
    }

    public byte[] encode(byte[] input) {
        if (!isInitialized) return input;

        try {
            ByteBuffer[] inputBuffers = encoder.getInputBuffers();
            ByteBuffer[] outputBuffers = encoder.getOutputBuffers();

            int inputBufferIndex = encoder.dequeueInputBuffer(0);
            if (inputBufferIndex >= 0) {
                ByteBuffer inputBuffer = inputBuffers[inputBufferIndex];
                inputBuffer.clear();
                inputBuffer.put(input);
                encoder.queueInputBuffer(inputBufferIndex, 0, input.length, 0, 0);
            }

            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            int outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, 0);
            if (outputBufferIndex >= 0) {
                ByteBuffer outputBuffer = outputBuffers[outputBufferIndex];
                byte[] encodedData = new byte[bufferInfo.size];
                outputBuffer.get(encodedData);
                encoder.releaseOutputBuffer(outputBufferIndex, false);
                return encodedData;
            }
        } catch (Exception e) {
            Log.e(TAG, "编码失败: " + e.getMessage());
        }
        return input;
    }

    public byte[] decode(byte[] input) {
        if (!isInitialized) return input;

        try {
            ByteBuffer[] inputBuffers = decoder.getInputBuffers();
            ByteBuffer[] outputBuffers = decoder.getOutputBuffers();

            int inputBufferIndex = decoder.dequeueInputBuffer(0);
            if (inputBufferIndex >= 0) {
                ByteBuffer inputBuffer = inputBuffers[inputBufferIndex];
                inputBuffer.clear();
                inputBuffer.put(input);
                decoder.queueInputBuffer(inputBufferIndex, 0, input.length, 0, 0);
            }

            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            int outputBufferIndex = decoder.dequeueOutputBuffer(bufferInfo, 0);
            if (outputBufferIndex >= 0) {
                ByteBuffer outputBuffer = outputBuffers[outputBufferIndex];
                byte[] decodedData = new byte[bufferInfo.size];
                outputBuffer.get(decodedData);
                decoder.releaseOutputBuffer(outputBufferIndex, false);
                return decodedData;
            }
        } catch (Exception e) {
            Log.e(TAG, "解码失败: " + e.getMessage());
        }
        return input;
    }

    public void release() {
        if (encoder != null) {
            encoder.stop();
            encoder.release();
            encoder = null;
        }
        if (decoder != null) {
            decoder.stop();
            decoder.release();
            decoder = null;
        }
        isInitialized = false;
        Log.d(TAG, "音频编解码器已释放");
    }
}