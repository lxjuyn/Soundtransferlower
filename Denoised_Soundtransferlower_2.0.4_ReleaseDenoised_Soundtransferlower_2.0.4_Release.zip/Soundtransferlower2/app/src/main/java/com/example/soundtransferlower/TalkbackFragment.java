package com.example.soundtransferlower;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class TalkbackFragment extends Fragment implements AudioRecorderPlayer.AudioDataSender, BluetoothService.MessageCallback {
    private static final long TALK_BUTTON_TIMEOUT = 600; // 按钮禁用时间（毫秒）
    private boolean isTalkButtonDisabled = false; // 按钮禁用状态标志
    private static final String TAG = "TalkbackFragment";
    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 1;
    private static final long RECEIVE_TIMEOUT = 800; // 接收超时时间（毫秒）
    private boolean isLoading = true;
    private static final long INACTIVITY_THRESHOLD_DISCONNECT = 50000; // 50秒断开阈值
    private long lastActivityTime = 0; // 最后活动时间戳
    private Runnable inactivityCheckRunnable; // 活动检测Runnable

    // 状态常量
    private int stateChangeCount = 0; // 状态切换计数器
    private static final int MAX_STATE_CHANGES = 2; // 最大状态切换次数
    private BluetoothDevice lastConnectedDevice = null; // 记录最后连接的设备
    private static final int STATE_IDLE = 0;
    private static final int STATE_TALKING = 1;
    private static final int STATE_RECEIVING = 2;

    private TextView tvStatus;
    private ListView deviceList;
    private Button btnRefresh, btnAudioMode, btnTalk, btnDisconnect, btnPair;
    private ArrayAdapter<BluetoothDevice> deviceAdapter;
    private List<BluetoothDevice> pairedDevices = new ArrayList<>();

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice targetDevice;

    private AudioManager audioManager;
    private AudioRecorderPlayer audioRecorderPlayer;

    private boolean isRecording = false;
    private boolean isSpeakerMode = false; // 初始为听筒模式
    private boolean isConnectionActive = false;
    private boolean isConnecting = false;
    private boolean isIncomingConnection = false;
    private int currentState = STATE_IDLE;

    // 蓝牙服务相关
    private BluetoothService bluetoothService;
    private boolean serviceBound = false;

    // 新增：连接设备信息
    private String connectedDeviceAddress;
    private String connectedDeviceName;

    // 新增：用于检测数据包数量
    private int receivedPacketCount = 0;
    private Handler checkPacketHandler = new Handler(Looper.getMainLooper());
    private Runnable checkPacketRunnable = new Runnable() {
        @Override
        public void run() {
            // 如果收到的包数量少于3个，则认为连接错误
            if (receivedPacketCount < 3) {
                switchToChatFragment();
            }
            receivedPacketCount = 0; // 重置计数
        }
    };

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshPairedDevices();
            handler.postDelayed(this, 5000);
        }
    };

    // 接收超时检测
    private Runnable receiveTimeoutRunnable = new Runnable() {
        @Override
        public void run() {
            if (currentState == STATE_RECEIVING) {
                Log.d(TAG, "接收超时，恢复空闲状态");
                setState(STATE_IDLE);
            }
        }
    };

    // 服务连接
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BluetoothService.LocalBinder binder = (BluetoothService.LocalBinder) service;
            bluetoothService = binder.getService();
            bluetoothService.registerCallback(TalkbackFragment.this);
            serviceBound = true;

            // 设置对讲模式
            bluetoothService.setMode(BluetoothService.MODE_TALKBACK);

            // 如果是从设备列表点击进入，尝试连接设备
            if (targetDevice != null) {
                connectToDevice(targetDevice);
            } else {
                // 否则启动服务器监听
                startServer();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_main, container, false);

        initViews(view);
        setLoadingState(); // 设置初始加载状态
        checkPermissions();
        initBluetooth();
        initAudio();
        setupListeners();

        // 绑定蓝牙服务
        Intent serviceIntent = new Intent(getActivity(), BluetoothService.class);
        getActivity().bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        handler.postDelayed(() -> {
            isLoading = false;
            setInitialState();
        }, 500);

        // 初始化活动检测计时器
        inactivityCheckRunnable = new Runnable() {
            @Override
            public void run() {
                checkInactivity();
                // 每1秒检查一次
                handler.postDelayed(this, 1000);
            }
        };

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // 释放所有资源
        disconnect();
        if (audioRecorderPlayer != null) {
            audioRecorderPlayer.release();
            audioRecorderPlayer = null;
        }
        handler.removeCallbacksAndMessages(null);
        checkPacketHandler.removeCallbacksAndMessages(null);
        try {
            getActivity().unregisterReceiver(bluetoothReceiver);
        } catch (Exception e) {
            Log.e(TAG, "取消注册广播接收器失败: " + e.getMessage());
        }

        // 解绑服务
        if (serviceBound) {
            if (bluetoothService != null) {
                bluetoothService.unregisterCallback(this);
            }
            getActivity().unbindService(serviceConnection);
            serviceBound = false;
        }
    }

    // 实现音频数据发送接口
    @Override
    public void sendAudioData(byte[] data) {
        if (serviceBound && bluetoothService != null && isConnectionActive) {
            bluetoothService.write(data, BluetoothService.MODE_TALKBACK);
            resetInactivityTimer();
        }
    }

    // 实现MessageCallback接口
    @Override
    public void onMessageReceived(String message, String deviceAddress) {
        // 对讲模式忽略文本消息，但计数
        receivedPacketCount++;
        // 重新启动检查任务
        checkPacketHandler.removeCallbacks(checkPacketRunnable);
        checkPacketHandler.postDelayed(checkPacketRunnable, 2000); // 2秒后检查
        Log.d(TAG, "收到文本消息，但对讲模式忽略: " + message);
    }

    @Override
    public void onConnectionStatusChanged(int state, String deviceName) {
        handler.post(() -> {
            switch (state) {
                case BluetoothService.STATE_CONNECTED:
                    tvStatus.setText("已连接: " + deviceName);
                    isConnectionActive = true;
                    isConnecting = false;
                    playConnectionSound();
                    setState(STATE_IDLE);
                    startInactivityTimer();
                    // 保存连接设备信息
                    connectedDeviceAddress = bluetoothService.getConnectedDeviceAddress();
                    connectedDeviceName = deviceName;
                    break;
                case BluetoothService.STATE_CONNECTING:
                    tvStatus.setText("连接中...");
                    isConnecting = true;
                    break;
                case BluetoothService.STATE_LISTEN:
                    tvStatus.setText("等待连接...");
                    isConnectionActive = false;
                    isConnecting = false;
                    break;
                case BluetoothService.STATE_NONE:
                    tvStatus.setText("未连接");
                    isConnectionActive = false;
                    isConnecting = false;
                    break;
            }
        });
    }

    @Override
    public void onTalkbackDataReceived(byte[] data, String deviceAddress) {
        // 首先检查是否是文本消息
        if (isTextMessage(data)) {
            // 如果是文本消息，转换为字符串并处理
            String message = new String(data, BluetoothService.TEXT_PREFIX_BYTES.length,
                    data.length - BluetoothService.TEXT_PREFIX_BYTES.length);

            // 通知主活动处理文本消息
            if (getActivity() instanceof MainActivityNew) {
                ((MainActivityNew) getActivity()).onMessageReceived(message, deviceAddress);
            }
        } else {
            // 是对讲数据，正常处理
            audioRecorderPlayer.playAudio(data, data.length);
            setState(STATE_RECEIVING);
            resetInactivityTimer();
        }
        // 计数
        receivedPacketCount++;
        checkPacketHandler.removeCallbacks(checkPacketRunnable);
        checkPacketHandler.postDelayed(checkPacketRunnable, 2000); // 2秒后检查
    }

    // 新增：实现 onNonTextDataReceived（对讲Fragment不需要处理，但接口要求）
    @Override
    public void onNonTextDataReceived(String deviceAddress) {
        // 对讲Fragment不需要处理此回调
    }

    // 检查是否是文本消息
    private boolean isTextMessage(byte[] data) {
        if (data.length < BluetoothService.TEXT_PREFIX_BYTES.length) {
            return false;
        }

        // 检查前几个字节是否是TEXT_PREFIX_BYTES
        for (int i = 0; i < BluetoothService.TEXT_PREFIX_BYTES.length; i++) {
            if (data[i] != BluetoothService.TEXT_PREFIX_BYTES[i]) {
                return false;
            }
        }

        return true;
    }

    private void initViews(View view) {
        tvStatus = view.findViewById(R.id.tvStatus);
        deviceList = view.findViewById(R.id.deviceList);
        btnRefresh = view.findViewById(R.id.btnRefresh);
        btnAudioMode = view.findViewById(R.id.btnAudioMode);
        btnTalk = view.findViewById(R.id.btnTalk);
        btnDisconnect = view.findViewById(R.id.btnDisconnect);
        btnPair = view.findViewById(R.id.btnPair);

        deviceAdapter = new DeviceListAdapter(getActivity(), R.layout.device_list_item, pairedDevices);
        deviceList.setAdapter(deviceAdapter);

        // 初始按钮文本
        btnAudioMode.setText("开始外放");
    }

    private void checkPermissions() {
        String[] permissions = {
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.MODIFY_AUDIO_SETTINGS
        };

        List<String> permissionsNeeded = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(getActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }

        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(getActivity(),
                    permissionsNeeded.toArray(new String[0]),
                    REQUEST_BLUETOOTH_PERMISSIONS);
        }
    }

    @SuppressLint("MissingPermission")
    private void initBluetooth() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            tvStatus.setText("蓝牙不可用");
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBtIntent);
        }

        // 注册蓝牙状态广播接收器
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED);
        getActivity().registerReceiver(bluetoothReceiver, filter);
    }

    private void initAudio() {
        audioManager = (AudioManager) getActivity().getSystemService(Context.AUDIO_SERVICE);
        // 传入Context而不是Fragment
        audioRecorderPlayer = new AudioRecorderPlayer(getActivity());
        audioRecorderPlayer.setAudioDataSender(this);
        setSpeakerMode(false); // 初始为听筒模式
    }

    private void setupListeners() {
        deviceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                targetDevice = pairedDevices.get(position);
                connectToDevice(targetDevice);
            }
        });

        btnRefresh.setOnClickListener(v -> refreshPairedDevices());

        btnAudioMode.setOnClickListener(v -> {
            isSpeakerMode = !isSpeakerMode;
            setSpeakerMode(isSpeakerMode);
            // 更新按钮文本
            if (isSpeakerMode) {
                btnAudioMode.setText("关闭外放");
            } else {
                btnAudioMode.setText("开启外放");
            }
        });
        btnDisconnect.setOnClickListener(v -> disconnect());
        btnPair.setOnClickListener(v -> {
            Intent intent = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
            startActivity(intent);
        });
        btnRefresh.setOnClickListener(v -> refreshPairedDevices());

        // 修改为点击监听器
        btnTalk.setOnClickListener(v -> {
            // 检查按钮是否被禁用
            if (isTalkButtonDisabled) {
                Toast.makeText(getActivity(), "请稍后再试", Toast.LENGTH_SHORT).show();
                return;
            }

            // 禁用按钮并设置超时
            disableTalkButtonTemporarily();

            // 原有功能逻辑
            if (isRecording) {
                stopTalking();
            } else {
                startTalking();
            }
        });
    }

    private void refreshPairedDevices() {
        if (bluetoothAdapter == null) return;

        @SuppressLint("MissingPermission") Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
        pairedDevices.clear();
        pairedDevices.addAll(devices);
        deviceAdapter.notifyDataSetChanged();
        Log.d(TAG, "刷新配对设备列表，数量: " + pairedDevices.size());
    }

    private void connectToDevice(BluetoothDevice device) {
        if (isConnectionActive || isConnecting) return;

        tvStatus.setText("连接中");
        isConnecting = true;
        btnTalk.setEnabled(false);
        btnDisconnect.setEnabled(false);

        if (serviceBound && bluetoothService != null) {
            // 使用蓝牙服务进行连接
            bluetoothService.setConnectionRole(true, device.getAddress());
        } else {
            Toast.makeText(getActivity(), "蓝牙服务未就绪", Toast.LENGTH_SHORT).show();
            isConnecting = false;
        }
    }

    private void startServer() {
        if (serviceBound && bluetoothService != null) {
            bluetoothService.setConnectionRole(false, null);
        }
    }

    private void handleConnectionLost() {
        Log.d(TAG, "连接丢失");
        handler.post(() -> {
            resetConnectionState();
            tvStatus.setText("连接断开");
        });
    }

    private void disableTalkButtonTemporarily() {
        isTalkButtonDisabled = true;
        btnTalk.setEnabled(false);
        btnTalk.setAlpha(0.5f); // 添加半透明效果表示禁用

        handler.postDelayed(() -> {
            isTalkButtonDisabled = false;
            // 只有在连接活跃时才重新启用按钮
            if (isConnectionActive) {
                btnTalk.setEnabled(true);
                btnTalk.setAlpha(1.0f); // 恢复不透明
                // 刷新按钮状态以确保UI一致
                setState(currentState);
            }
        }, TALK_BUTTON_TIMEOUT);
    }

    private void disconnect() {
        Log.d(TAG, "调用 disconnect() 方法");
        stopInactivityTimer();
        if (serviceBound && bluetoothService != null) {
            bluetoothService.stop();
        }

        handler.post(() -> {
            resetConnectionState();
            tvStatus.setText("已断开连接");
        });
    }

    private void resetConnectionState() {
        // 停止录音（如果正在录音）
        if (isRecording) {
            stopTalking();
        }

        // 重置连接相关状态
        isConnectionActive = false;
        isConnecting = false;
        isIncomingConnection = false;
        currentState = STATE_IDLE;
        stateChangeCount = 0; // 重置状态切换计数器

        // 重置UI状态
        btnTalk.setEnabled(false);
        btnTalk.setText("按下对讲");
        btnTalk.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.darker_gray));
        btnDisconnect.setEnabled(false);
        btnAudioMode.setEnabled(false);

        // 重新启用设备列表和刷新按钮
        deviceList.setEnabled(true);
        btnRefresh.setEnabled(true);
        btnPair.setEnabled(true);

        // 重启服务器监听
        startServer();
        isTalkButtonDisabled = false;
        btnTalk.setAlpha(1.0f);

        // 重置数据包计数
        receivedPacketCount = 0;
        checkPacketHandler.removeCallbacks(checkPacketRunnable);
    }

    // 添加计时器管理方法
    private void startInactivityTimer() {
        // 重置最后活动时间
        lastActivityTime = System.currentTimeMillis();
        // 启动计时器
        handler.postDelayed(inactivityCheckRunnable, 1000);
        Log.d(TAG, "启动活动检测计时器");
    }

    private void stopInactivityTimer() {
        handler.removeCallbacks(inactivityCheckRunnable);
        Log.d(TAG, "停止活动检测计时器");
    }

    private void resetInactivityTimer() {
        lastActivityTime = System.currentTimeMillis();
        Log.d(TAG, "重置活动检测计时器");
    }

    // 添加活动检测方法
    private void checkInactivity() {
        if (!isConnectionActive) return;

        long currentTime = System.currentTimeMillis();
        long inactiveDuration = currentTime - lastActivityTime;

        if (inactiveDuration >= INACTIVITY_THRESHOLD_DISCONNECT) {
            // 50秒无活动，断开连接
            Log.d(TAG, "50秒无活动，断开连接");
            disconnect();
            handler.post(() -> {
                Toast.makeText(getActivity(), "50秒无活动，连接已断开", Toast.LENGTH_LONG).show();
            });
        }
    }

    private void setSpeakerMode(boolean speaker) {
        try {
            if (speaker) {
                audioManager.setMode(AudioManager.MODE_NORMAL);
                audioManager.setSpeakerphoneOn(true);
                // 设置扬声器音量为15%
                int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);
                int targetVolume = (int) (maxVolume * 0.15);
                audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, targetVolume, 0);
            } else {
                // 修复听筒模式设置
                audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                audioManager.setSpeakerphoneOn(false);
                // 确保使用正确的音频流类型，设置听筒音量为最大
                int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);
                audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, maxVolume, 0);
            }
        } catch (Exception e) {
            Log.e(TAG, "设置音频模式失败: " + e.getMessage());
            // 防止崩溃，显示错误提示
            handler.post(() -> Toast.makeText(getActivity(), "音频模式切换失败", Toast.LENGTH_SHORT).show());
        }
    }

    // 设置状态
    @SuppressLint("MissingPermission")
    private void setState(int newState) {
        // 状态切换时增加计数器
        if (currentState != newState) {
            stateChangeCount++;
            Log.d(TAG, "状态切换计数: " + stateChangeCount);

            // 检查是否达到最大切换次数
            if (stateChangeCount >= MAX_STATE_CHANGES) {
                Log.d(TAG, "达到最大状态切换次数，将断开重连");
                stateChangeCount = 0; // 重置计数器

                // 播放提示音
                playConnectionSound();

                // 断开并重连
                if (lastConnectedDevice != null) {
                    disconnect();
                    handler.postDelayed(() -> {
                        connectToDevice(lastConnectedDevice);
                    }, 500); // 延迟500ms重连
                }
            }
        }
        currentState = newState;
        handler.post(() -> {
            switch (newState) {
                case STATE_IDLE:
                    tvStatus.setText("已连接: " + (bluetoothService != null ? bluetoothService.getConnectedDeviceAddress() : ""));
                    btnTalk.setEnabled(true);
                    btnTalk.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.holo_green_light));
                    // 确保音频模式切换按钮在空闲状态下启用
                    btnAudioMode.setEnabled(true);
                    if (!isTalkButtonDisabled) {
                        btnTalk.setText("按下对讲");
                    }
                    break;
                case STATE_TALKING:
                    tvStatus.setText("我方说话中");
                    btnAudioMode.setEnabled(false);
                    if (isTalkButtonDisabled) {
                        btnTalk.setText("作用中");
                    } else {
                        btnTalk.setText("对讲中,再次按下停止");
                        btnTalk.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.holo_red_light));
                        // 在说话状态下禁用音频模式切换
                    }
                    break;
                case STATE_RECEIVING:
                    tvStatus.setText("对方说话中");
                    btnTalk.setEnabled(false);
                    btnTalk.setText("对方说话中");
                    btnTalk.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.darker_gray));
                    // 在接收状态下禁用音频模式切换
                    btnAudioMode.setEnabled(false);
                    // 设置超时检测
                    handler.removeCallbacks(receiveTimeoutRunnable);
                    handler.postDelayed(receiveTimeoutRunnable, RECEIVE_TIMEOUT);
                    break;
            }
        });
    }

    private void startTalking() {
        if (!isConnectionActive || isRecording) return;

        Log.d(TAG, "开始说话");
        setState(STATE_TALKING);
        audioRecorderPlayer.startRecording();
        isRecording = true;
    }

    private void stopTalking() {
        if (!isRecording) return;
        Log.d(TAG, "停止说话");
        audioRecorderPlayer.stopRecording();
        isRecording = false;
        btnTalk.setText("作用中");
        setState(STATE_IDLE); // 这会重新启用音频模式切换按钮
    }

    // 新增方法：设置加载状态
    private void setLoadingState() {
        handler.post(() -> {
            tvStatus.setText("加载中...");
            // 禁用所有控件
            deviceList.setEnabled(false);
            btnRefresh.setEnabled(false);
            btnAudioMode.setEnabled(false);
            btnTalk.setEnabled(false);
            btnDisconnect.setEnabled(false);
            btnPair.setEnabled(false);
        });
    }

    // 新增方法：设置初始状态
    private void setInitialState() {
        handler.post(() -> {
            tvStatus.setText("未连接");
            // 重置所有按钮状态
            btnTalk.setEnabled(false);
            btnTalk.setText("按下对讲");
            btnTalk.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.darker_gray));
            btnDisconnect.setEnabled(false);
            btnAudioMode.setEnabled(false);

            // 启用初始控件
            deviceList.setEnabled(true);
            btnRefresh.setEnabled(true);
            btnPair.setEnabled(true);

            refreshPairedDevices();
            startServer(); // 确保启动监听
        });
    }

    private void playConnectionSound() {
        // 使用振动代替铃声
        try {
            // 获取振动服务
            Vibrator vibrator = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);

            // 检查设备是否支持振动
            if (vibrator != null && vibrator.hasVibrator()) {
                // 创建振动模式：振动500ms
                long[] pattern = {0, 500}; // 延迟0ms，振动500ms

                // 使用兼容API进行振动
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Android 8.0+ 使用新的振动API
                    VibrationEffect effect = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE);
                    vibrator.vibrate(effect);
                } else {
                    // 旧版本使用传统方法
                    vibrator.vibrate(500);
                }
            } else {
                Log.d(TAG, "设备不支持振动");
            }
        } catch (Exception e) {
            Log.e(TAG, "振动失败: " + e.getMessage());
        }
    }

    // 新增：切换到聊天Fragment
    private void switchToChatFragment() {
        if (getActivity() instanceof MainActivityNew) {
            String address = connectedDeviceAddress != null ? connectedDeviceAddress :
                    (targetDevice != null ? targetDevice.getAddress() : null);
            String name = connectedDeviceName != null ? connectedDeviceName :
                    (targetDevice != null ? targetDevice.getName() : "未知设备");
            if (address != null) {
                Toast.makeText(getActivity(), "检测到文本连接，正在切换...", Toast.LENGTH_SHORT).show();
                ((MainActivityNew) getActivity()).switchToFragment("ChatWorkFragment", address, name);
            }
        }
    }

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

            if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                Log.d(TAG, "设备已连接: " + device.getName());
                handler.post(() -> tvStatus.setText("已连接: " + device.getName()));
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                Log.d(TAG, "设备已断开: " + device.getName());
                handleConnectionLost();
            } else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                if (state == BluetoothAdapter.STATE_ON) {
                    refreshPairedDevices();
                    startServer();
                } else if (state == BluetoothAdapter.STATE_OFF) {
                    handler.post(() -> tvStatus.setText("蓝牙已关闭"));
                }
            }
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        refreshPairedDevices();
        startServer();
        handler.post(refreshRunnable);
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(refreshRunnable);
        handler.removeCallbacks(receiveTimeoutRunnable);
        checkPacketHandler.removeCallbacks(checkPacketRunnable);
        if (isRecording) {
            stopTalking();
        }
    }
}
