package com.example.soundtransferlower;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {
    private List<ChatWorkFragment.Message> messages;
    private SimpleDateFormat timeFormat;

    public MessageAdapter(List<ChatWorkFragment.Message> messages) {
        this.messages = messages;
        this.timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int layoutRes;
        if (viewType == 0) { // 发送的消息
            layoutRes = R.layout.item_message_sent;
        } else { // 接收的消息
            layoutRes = R.layout.item_message_received;
        }

        View view = LayoutInflater.from(parent.getContext()).inflate(layoutRes, parent, false);
        return new ViewHolder(view, viewType);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ChatWorkFragment.Message message = messages.get(position);
        holder.tvMessage.setText(message.getContent());

        // 设置时间
        if (message.getTimestamp() != null) {
            holder.tvTime.setText(timeFormat.format(message.getTimestamp()));
        }

        // 设置发送者标签（只在接收的消息中显示）
        if (holder.viewType == 1 && holder.tvSender != null) {
            holder.tvSender.setText(message.isSent() ? "我" : "对方");
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    @Override
    public int getItemViewType(int position) {
        return messages.get(position).isSent() ? 0 : 1;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvMessage;
        TextView tvTime;
        TextView tvSender; // 只在接收的消息布局中使用
        int viewType;

        public ViewHolder(View itemView, int viewType) {
            super(itemView);
            this.viewType = viewType;

            tvMessage = itemView.findViewById(R.id.tvMessage);
            tvTime = itemView.findViewById(R.id.tvTime);

            // 只在接收的消息布局中查找发送者TextView
            if (viewType == 1) {
                tvSender = itemView.findViewById(R.id.tvSender);
            }
        }
    }
}